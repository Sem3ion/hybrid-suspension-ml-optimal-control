# -*- coding: utf-8 -*-
"""
simulazione.py — Simulazioni del quarter-car usate per il COMFORT e per l'ANIMAZIONE.

  simula_ideale_vs_passivo : per l'animazione "fisica" (etichette), non usata di default.
  simula_closed_loop        : CLOSED-LOOP col ML. A ogni passo la rete legge la finestra di
                              a_z della cassa CONTROLLATA (feedback dell'accelerometro),
                              predice xi e forza (NORMALIZZANDO l'ingresso col Normalizzatore
                              del training) e li applica. E' il controllore reale.
  strada_demo               : profilo strada dimostrativo con dossi (per l'animazione).
  traiettorie_demo_ml / traiettorie_reali_ml : preparano i dati per l'animazione closed-loop.

Chiavi restituite (LEGENDA): strada=z_r; quota_cassa_ml/quota_ruota_ml (ramo ML),
  quota_cassa_pas/quota_ruota_pas (ramo passivo); forza; xi; acc_cassa_ml; acc_cassa_pas;
  x_pos (avanzamento longitudinale); N.
"""
import numpy as np
import torch

from fisica import passo_rk4, ricostruisci_strada, rms_accel_passiva
from reti import norm_a_xi, norm_a_forza


def simula_closed_loop(strada, strada_dot, vel, rete_xi, rete_forza, norm, auto, cfg, device):
    """Integra in CLOSED-LOOP il ramo controllato (ML) e in parallelo il ramo passivo (c_nom)
    sullo STESSO profilo strada. La rete decide xi e forza dalla finestra passata di a_z
    della cassa controllata. All'avvio la finestra e' riempita con zero (warm-up)."""
    N = len(strada); seq = cfg.seq_len; h = cfg.passo_t / cfg.n_sottopassi
    quota_cassa_ml = np.zeros(N); quota_ruota_ml = np.zeros(N)
    quota_cassa_pas = np.zeros(N); quota_ruota_pas = np.zeros(N)
    forza = np.zeros(N); xi = np.zeros(N, np.float32)
    acc_cassa_ml = np.zeros(N, np.float32); acc_cassa_pas = np.zeros(N)
    x = np.zeros(4); xp = np.zeros(4)
    rete_xi.eval(); rete_forza.eval()
    finestra = np.zeros(seq, np.float32)
    with torch.no_grad():
        for k in range(N):
            # finestra causale = ultimi seq campioni di accelerazione cassa CONTROLLATA
            if k >= seq:
                w = acc_cassa_ml[k - seq:k]
            else:
                finestra[:] = 0.0
                if k > 0:
                    finestra[seq - k:] = acc_cassa_ml[:k]
                w = finestra
            # NORMALIZZA con le statistiche del training, poi predice
            az_t = torch.as_tensor(norm.na(w), dtype=torch.float32, device=device).view(1, 1, seq)
            v_t = torch.tensor([[norm.nv(float(vel[k]))]], dtype=torch.float32, device=device)
            xi_k = norm_a_xi(float(rete_xi(az_t, v_t)), auto)
            forza_k = float(np.clip(norm_a_forza(float(rete_forza(az_t, v_t)), cfg),
                                    -cfg.forza_max, cfg.forza_max))
            c = auto.c_da_xi(xi_k)
            xi[k] = xi_k; forza[k] = forza_k

            quota_ruota_ml[k] = x[2] + strada[k]; quota_cassa_ml[k] = x[0] + quota_ruota_ml[k]
            quota_ruota_pas[k] = xp[2] + strada[k]; quota_cassa_pas[k] = xp[0] + quota_ruota_pas[k]
            acc_cassa_ml[k] = (-auto.rigid_molla * x[0] - c * (x[1] - x[3]) + forza_k) / auto.massa_cassa
            acc_cassa_pas[k] = (-auto.rigid_molla * xp[0] - auto.smorz_nom * (xp[1] - xp[3])) / auto.massa_cassa

            zr0 = strada_dot[k]; zr1 = strada_dot[k + 1] if k + 1 < N else strada_dot[k]
            for _ in range(cfg.n_sottopassi):
                x = passo_rk4(x, c, forza_k, zr0, zr1, auto, h)
                xp = passo_rk4(xp, auto.smorz_nom, 0.0, zr0, zr1, auto, h)

    x_pos = np.cumsum(np.maximum(vel, 0.0) * cfg.passo_t)
    return dict(strada=strada, quota_cassa_ml=quota_cassa_ml, quota_ruota_ml=quota_ruota_ml,
                quota_cassa_pas=quota_cassa_pas, quota_ruota_pas=quota_ruota_pas,
                forza=forza, xi=xi, acc_cassa_ml=acc_cassa_ml, acc_cassa_pas=acc_cassa_pas,
                x_pos=x_pos, N=N)


def strada_demo(auto, cfg):
    """Profilo strada dimostrativo: fondo liscio + dossi periodici attorno alla risonanza
    (dove l'effetto e' massimo). Restituisce (strada z_r, z_r', velocita' v)."""
    N = int(cfg.anim_secondi * cfg.freq_campion)
    t = np.arange(N) * cfg.passo_t
    v0 = cfg.anim_vel
    vel = np.full(N, v0)
    x_pos = np.cumsum(vel * cfg.passo_t)
    passo_dossi = v0 / 1.6                              # spaziatura -> ~1.6 Hz (banda risonanza)
    x_primo = max(4.0, v0 * cfg.seq_len * cfg.passo_t + 2.0)   # primo dosso dopo il warm-up
    zr = np.zeros(N)
    for xb in np.arange(x_primo, x_pos[-1], passo_dossi):
        zr += cfg.anim_dosso * np.exp(-((x_pos - xb) ** 2) / (2 * 0.45 ** 2))
    rng = np.random.default_rng(0)
    zr += cfg.anim_texture * (np.sin(2 * np.pi * 2.5 * t) + 0.6 * rng.standard_normal(N))
    return zr, np.gradient(zr, cfg.passo_t), vel


def traiettorie_demo_ml(rete_xi, rete_forza, norm, auto, cfg, device):
    """Animazione su strada demo, controllo closed-loop dal ML."""
    zr, zr_dot, vel = strada_demo(auto, cfg)
    return simula_closed_loop(zr, zr_dot, vel, rete_xi, rete_forza, norm, auto, cfg, device)


def traiettorie_reali_ml(az, vel, rete_xi, rete_forza, norm, auto, cfg, device):
    """Animazione su traccia reale: strada ricostruita+calibrata, controllo closed-loop dal ML."""
    zr, zr_dot = ricostruisci_strada(az, cfg)
    if cfg.calibra_strada:
        f = np.clip(np.sqrt(np.mean(az ** 2)) / (rms_accel_passiva(zr_dot, auto, cfg) + 1e-9), 0.2, 20.0)
        zr *= f; zr_dot *= f
    return simula_closed_loop(zr, zr_dot, vel, rete_xi, rete_forza, norm, auto, cfg, device)
