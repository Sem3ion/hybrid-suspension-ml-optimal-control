# -*- coding: utf-8 -*-
"""
dati.py — Caricamento tracce reali, costruzione finestre per il ML e NORMALIZZAZIONE
degli ingressi calcolata SOLO dai dati di training.

Perche' cosi': normalizzare "a mano" (es. dividere per 30) e' arbitrario. Il modo
corretto e' standardizzare con MEDIA e DEVIAZIONE STANDARD che EMERGONO dal training,
e riusare le stesse statistiche su validazione e in inferenza.
"""
import os
import glob
import pickle
import numpy as np

from fisica import rimuovi_offset


def carica_tracce(cfg):
    """Scarica il dataset road-quality (kagglehub) e lo divide in 2 tracce di TRAINING e
    1 di VALIDAZIONE (mai vista). Ogni traccia e' una coppia (a_z, v). Se il dataset non
    c'e', genera 3 tracce sintetiche distinte per far girare comunque il codice."""
    try:
        import kagglehub
        cartella = kagglehub.dataset_download("nickkotarelas/road-quality-dataset")
        files = sorted(glob.glob(os.path.join(cartella, "**", "*.pkl"), recursive=True))
    except Exception:
        files = []

    train, val = [], []
    if len(files) >= 3:
        print(f"  [ok] {len(files)} tracce reali -> {len(files) - 1} train / 1 validazione "
              f"({os.path.basename(files[-1])})")
        for gruppo, dest in ((files[:-1], train), ([files[-1]], val)):
            for pkl in gruppo:
                with open(pkl, "rb") as f:
                    d = pickle.load(f)
                imu = d["imu"]
                t_imu = np.array(imu["time"]["rel"], dtype=float)
                # sceglie l'asse accelerometrico con media assoluta maggiore (il verticale)
                medie = {k: abs(np.mean(vv)) for k, vv in imu["accel"].items()}
                asse = max(medie, key=medie.get)
                az = rimuovi_offset(np.array(imu["accel"][asse], dtype=float), cfg.freq_campion)
                t_gps = np.array(d["gps"]["time"]["rel"], dtype=float)
                v_gps = np.array(d["gps"]["speed"], dtype=float)
                v = np.interp(t_imu, t_gps, v_gps)     # velocita' allineata all'IMU
                dest.append((az, v))
    else:
        print("  [!] Dataset reale assente: genero 3 tracce sintetiche (2 train / 1 val).")
        for i in range(3):
            rng = np.random.default_rng(42 + i)
            N = 9000
            t = np.linspace(0, 90, N)
            v0 = [8.0, 15.0, 26.0][i]
            v = np.clip(v0 + 7.0 * np.sin(2 * np.pi * (0.01 + 0.004 * i) * t) + rng.normal(0, 0.2, N), 3.0, 33.0)
            f_strada = 0.6 + 0.9 * v / 10.0
            az = np.sin(2 * np.pi * f_strada * t) * (0.7 + 0.05 * v) + rng.normal(0, 0.15, N)
            (train if i < 2 else val).append((az, v))
    return train, val


def _lavora_una_traccia(args):
    """Genera le etichette di UNA traccia (funzione a livello di modulo per il multiprocessing)."""
    auto, cfg, az, v = args
    from controllo import GeneratoreEtichette
    return GeneratoreEtichette(auto, cfg).genera(az, v)


def costruisci_finestre(tracce, auto, cfg, n_worker=0):
    """Per ogni traccia genera le etichette (in parallelo sui core, le tracce sono
    indipendenti) e taglia le finestre scorrevoli per il ML:
        finestra_az[i] = ultimi seq_len campioni di a_z (l'ingresso temporale)
        vel[i]         = velocita' corrente
        target_xi[i], target_forza[i] = etichette all'istante i
        rapporto_r[i]  = frequenza r all'istante i (solo per le tabelle)
    Restituisce array numpy + statistiche comfort (rms passiva, rms ideale) per traccia."""
    if n_worker and n_worker > 1 and len(tracce) > 1:
        try:
            import multiprocessing as mp
            with mp.get_context("spawn").Pool(min(n_worker, len(tracce))) as pool:
                uscite = pool.map(_lavora_una_traccia, [(auto, cfg, az, v) for az, v in tracce])
        except Exception as e:
            print(f"    [i] parallelo non riuscito ({e}); uso seriale")
            from controllo import GeneratoreEtichette
            gen = GeneratoreEtichette(auto, cfg)
            uscite = [gen.genera(az, v) for az, v in tracce]
    else:
        from controllo import GeneratoreEtichette
        gen = GeneratoreEtichette(auto, cfg)
        uscite = [gen.genera(az, v) for az, v in tracce]

    finestra_az, vel, target_xi, target_forza, rapporto_r = [], [], [], [], []
    comfort = []
    for (az, v), out in zip(tracce, uscite):
        comfort.append((np.sqrt(np.mean(out["acc_passiva"] ** 2)),
                        np.sqrt(np.mean(out["acc_ideale"] ** 2))))
        for i in range(cfg.seq_len, out["N"]):
            if v[i] < 2.0:                    # scarta l'auto quasi ferma
                continue
            finestra_az.append(az[i - cfg.seq_len:i])
            vel.append(v[i])
            target_xi.append(out["xi"][i])
            target_forza.append(out["forza"][i])
            rapporto_r.append(out["r"][i])
    return (np.array(finestra_az, dtype=np.float32), np.array(vel, dtype=np.float32),
            np.array(target_xi, dtype=np.float32), np.array(target_forza, dtype=np.float32),
            np.array(rapporto_r, dtype=np.float32), comfort)


class Normalizzatore:
    """Standardizza gli ingressi delle reti (a_z e v) con MEDIA e DEV.STD calcolate
    SOLO dal training. I numeri di normalizzazione EMERGONO dai dati, non sono fissati a
    mano; le stesse statistiche si applicano poi a validazione e closed-loop."""

    def __init__(self, finestra_az_train, vel_train):
        self.media_az = float(np.mean(finestra_az_train))
        self.std_az = float(np.std(finestra_az_train) + 1e-8)
        self.media_v = float(np.mean(vel_train))
        self.std_v = float(np.std(vel_train) + 1e-8)

    def na(self, az):
        """Normalizza l'accelerazione a_z (finestra o valore)."""
        return (az - self.media_az) / self.std_az

    def nv(self, v):
        """Normalizza la velocita' v."""
        return (v - self.media_v) / self.std_v

    def __repr__(self):
        return (f"Normalizzatore(a_z: media={self.media_az:+.4f} std={self.std_az:.4f} | "
                f"v: media={self.media_v:.3f} std={self.std_v:.3f})")
