# -*- coding: utf-8 -*-
"""
grafica.py — Figura riassuntiva dei risultati e ANIMAZIONE di confronto (con vs senza
intervento). Non forza mai il backend 'Agg' a livello globale, cosi' la finestra
interattiva dell'animazione puo' aprirsi.
"""
import os
import numpy as np

from controllo import xi_da_r, kp_da_r, RADQ2


def salva_figura(xi_true, xi_pred, forza_true, forza_pred, r_val, rms_pas, rms_ml, cfg, auto, path):
    """4 pannelli: xi(t) target vs ML, forza(t) target vs ML, curva xi/kp vs r (regola √2),
    barra comfort (RMS accel cassa passiva vs controllata dal ML)."""
    try:
        import matplotlib.pyplot as plt      # niente use('Agg'): non blocca l'animazione
    except Exception as e:
        print(f"    [i] matplotlib non disponibile, salto la figura ({e})")
        return
    fig, ax = plt.subplots(2, 2, figsize=(13, 8))
    fig.suptitle("Sospensione 2 GDL Peugeot 207 — controllo appreso (ML) vs passivo",
                 fontsize=13, fontweight="bold")

    n = min(800, len(xi_true)); tt = np.arange(n) * cfg.passo_t
    ax[0, 0].plot(tt, xi_true[:n], "r-", lw=1.0, label="xi target (fisico)")
    ax[0, 0].plot(tt, xi_pred[:n], "g-", lw=1.0, alpha=0.8, label="xi ML")
    ax[0, 0].set_title("xi(t): fattore di smorzamento"); ax[0, 0].set_xlabel("t [s]")
    ax[0, 0].legend(fontsize=8); ax[0, 0].grid(alpha=0.3)

    ax[0, 1].plot(tt, forza_true[:n], "r-", lw=1.0, label="forza target")
    ax[0, 1].plot(tt, forza_pred[:n], "b-", lw=1.0, alpha=0.8, label="forza ML")
    ax[0, 1].axhline(cfg.forza_max, ls=":", c="k"); ax[0, 1].axhline(-cfg.forza_max, ls=":", c="k")
    ax[0, 1].set_title("Forza attuatore [N] (saturata)"); ax[0, 1].set_xlabel("t [s]")
    ax[0, 1].legend(fontsize=8); ax[0, 1].grid(alpha=0.3)

    rr = np.linspace(0.3, 4.0, 200)
    axL = ax[1, 0]
    sub = np.random.default_rng(0).choice(len(r_val), size=min(3000, len(r_val)), replace=False)
    axL.scatter(r_val[sub], xi_true[sub], s=3, alpha=0.15, c="orange", label="target (dati)")
    axL.plot(rr, xi_da_r(rr, cfg), "-", c="darkred", lw=2, label="legge xi(r)")
    axL.axvline(RADQ2, ls="--", c="k", alpha=0.7); axL.text(RADQ2 + 0.05, 0.55, "r=√2", fontsize=9)
    axL.set_xlabel("r = omega/omega_n"); axL.set_ylabel("xi", color="darkred"); axL.grid(alpha=0.3)
    axL.legend(fontsize=7, loc="center right"); axL.set_title("xi e kp vs frequenza r")
    axR = axL.twinx(); axR.plot(rr, kp_da_r(rr, cfg), "-", c="teal", lw=2)
    axR.set_ylabel("kp attuatore [Ns/m]", color="teal")

    migliora = 100 * (1 - rms_ml / rms_pas)
    ax[1, 1].bar(["passiva\n(c_nom)", "controllata\n(ML)"], [rms_pas, rms_ml], color=["gray", "seagreen"])
    ax[1, 1].set_title(f"RMS accel. cassa (comfort, valori ML) — {migliora:.0f}% meglio")
    ax[1, 1].set_ylabel("RMS a_z [m/s^2]"); ax[1, 1].grid(alpha=0.3, axis="y")

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(path, dpi=120)
    plt.close(fig)
    print(f"    [ok] Figura salvata: {os.path.basename(path)}")


# --- geometria (metri) del quarter-car disegnato, scala realistica ---
_RAGGIO_RUOTA = 0.33
_RAGGIO_MOZZO = 0.13
_LARGH_CASSA = 1.9
_ALT_CASSA = 0.55
_LUCE_STRUT = 0.42
_QUOTA_BASE_CASSA = 2 * _RAGGIO_RUOTA + _LUCE_STRUT   # quota base cassa a riposo


def _molla_zigzag(xc, y0, y1, spire=6, largh=0.14):
    ys = np.linspace(y0, y1, 2 * spire + 2)
    xs = np.full_like(ys, xc); xs[1:-1:2] = xc - largh / 2; xs[2:-1:2] = xc + largh / 2
    return xs, ys


def _pannello(ax, colore, titolo):
    from matplotlib.patches import Circle, Rectangle, Polygon
    asfalto = Polygon([[0, 0]], closed=True, fc="0.78", ec="0.35", lw=1.0, zorder=1)
    strada, = ax.plot([], [], "-", c="0.15", lw=2.5, zorder=2)
    ruota = Circle((0, 0), _RAGGIO_RUOTA, fc="0.15", ec="black", lw=1.5, zorder=5)
    mozzo = Circle((0, 0), _RAGGIO_MOZZO, fc="0.7", ec="black", lw=1.0, zorder=6)
    cassa = Rectangle((0, 0), _LARGH_CASSA, _ALT_CASSA, fc=colore, ec="black", lw=1.8, alpha=0.92, zorder=5)
    molla, = ax.plot([], [], "-", c="crimson", lw=2.0, zorder=4)
    ammort, = ax.plot([], [], "-", c="royalblue", lw=5.0, solid_capstyle="butt", zorder=4)
    ax.axhline(_QUOTA_BASE_CASSA + _ALT_CASSA / 2, ls=":", c="green", alpha=0.5, zorder=3)  # quota neutra
    txt = ax.text(0.015, 0.96, "", transform=ax.transAxes, fontsize=10, va="top", zorder=8,
                  bbox=dict(boxstyle="round", fc="white", ec="0.6", alpha=0.85))
    for p in (asfalto, ruota, mozzo, cassa):
        ax.add_patch(p)
    ax.set_title(titolo, fontsize=12, fontweight="bold"); ax.set_ylabel("quota [m]")
    ax.set_aspect("equal", adjustable="box"); ax.grid(True, ls="--", alpha=0.25)
    return dict(asfalto=asfalto, strada=strada, ruota=ruota, mozzo=mozzo, cassa=cassa,
                molla=molla, ammort=ammort, txt=txt)


def anima_confronto(traj, cfg, path_video=None):
    """Due pannelli impilati: SOPRA con controllo ML, SOTTO passivo. La ruota (tangente
    all'asfalto) segue i dossi; con il controllo la cassa resta piu' vicina alla linea
    verde di riferimento. Apre la finestra interattiva e (se ffmpeg c'e') salva l'MP4."""
    try:
        import matplotlib
        if not cfg.mostra_anim:
            matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.animation as animation
    except Exception as e:
        print(f"    [i] animazione non disponibile ({e})"); return

    g = cfg.anim_gain; W = 4.5; passo = max(1, cfg.anim_step)
    frame_idx = range(0, traj["N"], passo); dt = cfg.passo_t
    x_pos = traj["x_pos"]; strada_y = traj["strada"] * g
    cassa_ml_y = _QUOTA_BASE_CASSA + traj["quota_cassa_ml"] * g
    cassa_pas_y = _QUOTA_BASE_CASSA + traj["quota_cassa_pas"] * g

    fig, (axT, axB) = plt.subplots(2, 1, figsize=(12, 8.2), sharex=True)
    fig.suptitle("Peugeot 207 sulla stessa strada — controllo ML vs passivo",
                 fontsize=13, fontweight="bold")
    A = _pannello(axT, "seagreen", "CON controllo (ML: xi + forza)")
    B = _pannello(axB, "0.55", "SENZA controllo (passivo c_nom)")
    for ax in (axT, axB):
        ax.set_ylim(-0.3, _QUOTA_BASE_CASSA + _ALT_CASSA + 0.5)
    axB.set_xlabel("posizione strada [m]")
    ybot = -0.3

    def disegna(P, k, cassa_y):
        xc = x_pos[k]; mask = (x_pos >= xc - W) & (x_pos <= xc + W)
        rx = x_pos[mask]; ry = strada_y[mask]
        P["strada"].set_data(rx, ry)
        P["asfalto"].set_xy(np.column_stack([np.r_[rx, rx[-1], rx[0]], np.r_[ry, ybot, ybot]]))
        centro_ruota = strada_y[k] + _RAGGIO_RUOTA            # ruota TANGENTE all'asfalto
        P["ruota"].center = (xc, centro_ruota); P["mozzo"].center = (xc, centro_ruota)
        P["cassa"].set_xy((xc - _LARGH_CASSA / 2, cassa_y[k]))
        top_ruota = centro_ruota + _RAGGIO_RUOTA
        sx, sy = _molla_zigzag(xc - 0.28, top_ruota, cassa_y[k]); P["molla"].set_data(sx, sy)
        P["ammort"].set_data([xc + 0.28, xc + 0.28], [top_ruota, cassa_y[k]])

    def aggiorna(k):
        disegna(A, k, cassa_ml_y); disegna(B, k, cassa_pas_y)
        rms_ml = np.sqrt(np.mean(traj["acc_cassa_ml"][:k + 1] ** 2))
        rms_pas = np.sqrt(np.mean(traj["acc_cassa_pas"][:k + 1] ** 2))
        A["txt"].set_text(f"t={k*dt:4.1f}s   xi={traj['xi'][k]:.2f}   forza={traj['forza'][k]:+5.0f} N"
                          f"   RMS a_z={rms_ml:.2f}")
        B["txt"].set_text(f"t={k*dt:4.1f}s   c=c_nom fisso                RMS a_z={rms_pas:.2f}")
        xc = x_pos[k]; axT.set_xlim(xc - W, xc + W); axB.set_xlim(xc - W, xc + W)
        return ()

    anim = animation.FuncAnimation(fig, aggiorna, frames=frame_idx,
                                   interval=1000 / cfg.anim_fps, blit=False, repeat=True)
    if path_video and cfg.salva_video:
        try:
            from matplotlib.animation import FFMpegWriter
            anim.save(path_video, writer=FFMpegWriter(fps=cfg.anim_fps, bitrate=2600), dpi=120)
            print(f"    [ok] Video salvato: {os.path.basename(path_video)}")
        except Exception as e:
            print(f"    [i] MP4 non salvato (installa ffmpeg: 'brew install ffmpeg'). {e}")
    if cfg.mostra_anim:
        plt.show()
    else:
        plt.close(fig)
    return anim
