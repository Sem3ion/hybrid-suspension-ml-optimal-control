# -*- coding: utf-8 -*-
"""
fisica.py — Modello dinamico quarter-car a 2 GDL, integratore RK4, ricostruzione del
profilo strada dai dati e stima causale della frequenza di eccitazione.

LEGENDA VARIABILI (valida per tutto il pacchetto):
    z_r = quota della STRADA sotto la ruota        [m]   (ingresso/disturbo)
    z_u = quota verticale della RUOTA              [m]   (massa non sospesa)
    z_s = quota verticale della CASSA              [m]   (massa sospesa, "il cielo")
    apice '  = velocita' [m/s] ; apice '' = accelerazione [m/s^2]
    a_z = z_s'' : accelerazione verticale della cassa (cio' che misura l'IMU)
    vel_rel = z_s' - z_u' : velocita' RELATIVA di sospensione (corsa)
Stato integrato x = [x1, x2, x3, x4]:
    x1 = z_s - z_u  (corsa sospensione)        x2 = z_s'  (velocita' cassa)
    x3 = z_u - z_r  (deflessione pneumatico)   x4 = z_u'  (velocita' ruota)
"""
import numpy as np
import scipy.signal as signal


def derivata_stato(x, c, forza_att, zr_dot, auto):
    """Derivata dello stato dx/dt del quarter-car.
    Ingressi: c = smorzamento corrente [Ns/m], forza_att = forza attuatore [N],
              zr_dot = velocita' della strada z_r' [m/s]. Restituisce dx/dt (4,)."""
    m_s, m_u = auto.massa_cassa, auto.massa_ruota
    k_s, k_t = auto.rigid_molla, auto.rigid_gomma
    x1, x2, x3, x4 = x
    vel_rel = x2 - x4
    dx1 = x2 - x4
    dx2 = (-k_s * x1 - c * vel_rel + forza_att) / m_s            # z_s'' (accel. cassa)
    dx3 = x4 - zr_dot
    dx4 = ( k_s * x1 + c * vel_rel - forza_att - k_t * x3) / m_u  # z_u'' (accel. ruota)
    return np.array([dx1, dx2, dx3, dx4])


def passo_rk4(x, c, forza_att, zr0, zr1, auto, h):
    """Un passo di Runge-Kutta 4 (h = passo). zr0, zr1 = velocita' strada a inizio/fine passo."""
    zrm = 0.5 * (zr0 + zr1)
    k1 = derivata_stato(x, c, forza_att, zr0, auto)
    k2 = derivata_stato(x + 0.5 * h * k1, c, forza_att, zrm, auto)
    k3 = derivata_stato(x + 0.5 * h * k2, c, forza_att, zrm, auto)
    k4 = derivata_stato(x + h * k3, c, forza_att, zr1, auto)
    return x + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def rimuovi_offset(az, fs, fc=0.1):
    """Passa-alto zero-fase per togliere offset/deriva dall'accelerazione misurata."""
    b, a = signal.butter(2, fc / (0.5 * fs), btype="highpass")
    return signal.filtfilt(b, a, az)


def ricostruisci_strada(az, cfg):
    """Doppia integrazione (con passa-alto anti-deriva) di a_z -> profilo strada z_r e z_r'.
    L'AMPIEZZA qui e' solo nominale: verra' CALIBRATA sui dati in controllo.py."""
    fs = cfg.freq_campion
    b, a = signal.butter(2, 0.3 / (0.5 * fs), btype="highpass")
    vel = signal.filtfilt(b, a, np.cumsum(az) / fs)      # 1a integrazione -> velocita'
    zr  = signal.filtfilt(b, a, np.cumsum(vel) / fs)     # 2a integrazione -> spostamento
    rms = np.sqrt(np.mean(zr ** 2)) + 1e-9
    zr = zr * (cfg.strada_rms_nom / rms)                 # scala nominale (poi ricalibrata)
    return zr.astype(float), np.gradient(zr, cfg.passo_t).astype(float)


def velocita_cassa_misurata(az, cfg):
    """Velocita' verticale della cassa stimata CAUSALMENTE dall'a_z del sensore:
    integrale singolo passa-alto (lfilter = causale, usa solo il passato).
    E' la grandezza su cui reagisce lo skyhook REALE."""
    fs = cfg.freq_campion
    b, a = signal.butter(2, 0.3 / (0.5 * fs), btype="highpass")
    return signal.lfilter(b, a, np.cumsum(az) / fs)


def stima_frequenza(az, cfg, auto):
    """Rapporto di frequenza r = omega/omega_n stimato CAUSALMENTE dall'a_z:
       omega = RMS_finestra(a_z) / RMS_finestra(integrale a_z), su finestra TRAILING
       (solo campioni passati). E' scala-invariante: cresce con velocita' E rugosita'.
    Serve alla regola √2 per decidere xi e kp."""
    fs = cfg.freq_campion
    b, a = signal.butter(2, 0.3 / (0.5 * fs), btype="highpass")
    vz = signal.lfilter(b, a, np.cumsum(az) / fs)        # integrale causale di a_z
    w = cfg.finestra_freq

    def rms_trailing(s):
        somma = np.convolve(s * s, np.ones(w), mode="full")[:len(s)] / w  # media finestra passata
        return np.sqrt(np.maximum(somma, 0.0) + 1e-12)

    omega = rms_trailing(az) / (rms_trailing(vz) + 1e-9)
    return np.clip(omega / auto.puls_nat_cassa, 0.15, cfg.r_max)


def rms_accel_passiva(zr_dot, auto, cfg):
    """RMS dell'accelerazione cassa del modello PASSIVO (c_nom, senza attuatore).
    Serve per CALIBRARE l'ampiezza strada sui dati (vedi controllo.py): NON e' un numero
    magico, e' cio' che permette di scalare z_r finche' il passivo riproduce l'a_z misurato."""
    N = len(zr_dot)
    xp = np.zeros(4)
    h = cfg.passo_t / cfg.n_sottopassi
    acc = 0.0
    for k in range(N):
        acc += (-auto.rigid_molla * xp[0] - auto.smorz_nom * (xp[1] - xp[3])) ** 2
        zr0 = zr_dot[k]
        zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
        for _ in range(cfg.n_sottopassi):
            xp = passo_rk4(xp, auto.smorz_nom, 0.0, zr0, zr1, auto, h)
    return np.sqrt(acc / N) / auto.massa_cassa
