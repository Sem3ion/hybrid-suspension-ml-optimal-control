# -*- coding: utf-8 -*-
"""
reti.py — Le DUE reti neurali (ricevono ingressi GIA' normalizzati dal Normalizzatore).

  ReteXi    (TCN dilatata): dalla finestra di a_z stima la FREQUENZA di eccitazione e,
                            tramite la regola √2, produce il fattore di smorzamento xi.
  ReteForza (CNN):          dalla finestra di a_z ricostruisce la VELOCITA' della cassa e
                            compone la FORZA skyhook dell'attuatore.

Nessuna feature "pronta" (frequenza/velocita') viene passata a mano: le reti devono
IMPARARE a stimarle dai campioni grezzi. Non e' un oracolo.

Normalizzazione delle USCITE (target) tramite LIMITI FISICI, non numeri arbitrari:
  - xi    -> range realizzabile dell'ammortizzatore [xi(c_min), xi(c_max)]  (Sigmoid)
  - forza -> limite dell'attuatore [-forza_max, forza_max]                  (Tanh)
"""
import torch
import torch.nn as nn


class ReteXi(nn.Module):
    """TCN 1D con dilatazioni crescenti (1,2,4,8) per un ampio contesto temporale."""

    def __init__(self, seq_len, hidden=128):
        super().__init__()
        self.tcn = nn.Sequential(
            nn.Conv1d(1, 32, 3, padding=1, dilation=1), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 32, 3, padding=2, dilation=2), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 3, padding=4, dilation=4), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 64, 3, padding=8, dilation=8), nn.BatchNorm1d(64), nn.ReLU(),
        )
        with torch.no_grad():                         # dimensione flatten dalla finestra fissa
            self.tcn.eval()
            n_flat = self.tcn(torch.zeros(1, 1, seq_len)).flatten(1).size(1)
            self.tcn.train()
        self.fc = nn.Sequential(nn.Linear(n_flat + 1, hidden), nn.ReLU(), nn.Dropout(0.2))
        self.testa = nn.Sequential(nn.Linear(hidden, 32), nn.ReLU(), nn.Linear(32, 1), nn.Sigmoid())

    def forward(self, az_norm, v_norm):
        """az_norm: (B,1,seq) normalizzata ; v_norm: (B,1) normalizzata. Uscita: xi_norm in (0,1)."""
        feat = self.tcn(az_norm).flatten(1)
        return self.testa(self.fc(torch.cat((feat, v_norm), dim=1)))


class ReteForza(nn.Module):
    """CNN 1D con GELU (regressione piu' liscia) per stimare la forza attuatore."""

    def __init__(self, seq_len, hidden=128):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(1, 32, 5, padding=2), nn.BatchNorm1d(32), nn.GELU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, 3, padding=1), nn.BatchNorm1d(64), nn.GELU(), nn.MaxPool1d(2),
        )
        with torch.no_grad():
            self.conv.eval()
            n_flat = self.conv(torch.zeros(1, 1, seq_len)).flatten(1).size(1)
            self.conv.train()
        self.fc = nn.Sequential(nn.Linear(n_flat + 1, hidden), nn.GELU(), nn.Dropout(0.2))
        self.testa = nn.Sequential(nn.Linear(hidden, 32), nn.GELU(), nn.Linear(32, 1), nn.Tanh())

    def forward(self, az_norm, v_norm):
        """Uscita: forza_norm in (-1,1)."""
        feat = self.conv(az_norm).flatten(1)
        return self.testa(self.fc(torch.cat((feat, v_norm), dim=1)))


def crea_reti(cfg):
    """Istanzia le due reti separate."""
    return ReteXi(cfg.seq_len), ReteForza(cfg.seq_len)


# --- Scalatura dei TARGET tramite limiti FISICI (documentata, non arbitraria) ---
def limiti_xi(auto):
    """Range realizzabile del fattore di smorzamento, dai limiti del damper [c_min,c_max]."""
    return auto.xi_da_c(auto.smorz_min), auto.xi_da_c(auto.smorz_max)


def xi_a_norm(xi, auto):
    lo, hi = limiti_xi(auto)
    return (xi - lo) / (hi - lo)                 # xi fisico -> (0,1) per la Sigmoid


def norm_a_xi(u, auto):
    lo, hi = limiti_xi(auto)
    return lo + u * (hi - lo)                     # (0,1) -> xi fisico


def forza_a_norm(forza, cfg):
    return forza / cfg.forza_max                  # [N] -> (-1,1) per la Tanh


def norm_a_forza(u, cfg):
    return u * cfg.forza_max                       # (-1,1) -> [N]
