# -*- coding: utf-8 -*-
"""
main.py — Orchestratore SOTTILE: mette in fila i moduli e mostra il flusso a colpo d'occhio.

PIPELINE:
  1. carica le tracce reali (2 train / 1 validazione)
  2. genera le ETICHETTE ideali (controllo.py) e taglia le finestre (dati.py)
  3. calcola la NORMALIZZAZIONE dai soli dati di training (dati.Normalizzatore)
  4. addestra DUE reti separate (reti.py): una per xi, una per la forza attuatore
  5. valuta su traccia mai vista (R^2, MAE) e misura il COMFORT in closed-loop
  6. salva la figura e l'animazione di confronto

Cosa fa il ML: dalla finestra di accelerazione a_z (+ velocita' v) impara a stimare lo
stato (frequenza e velocita' della cassa) e a produrre il controllo (xi e forza). Non e'
un oracolo: non riceve ne' la frequenza ne' la velocita' gia' pronte, deve dedurle.
"""
import os
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import r2_score, mean_absolute_error

from config import Auto, Config
from hardware import rileva_hardware
from dati import carica_tracce, costruisci_finestre, Normalizzatore
from controllo import GeneratoreEtichette, kp_da_r, RADQ2
from reti import crea_reti, xi_a_norm, norm_a_xi, forza_a_norm, norm_a_forza
from simulazione import traiettorie_demo_ml, traiettorie_reali_ml, simula_closed_loop
from fisica import ricostruisci_strada, rms_accel_passiva
from grafica import salva_figura, anima_confronto


def main():
    t0 = time.time()
    auto, cfg = Auto(), Config()
    base = os.path.dirname(os.path.abspath(__file__))
    path_xi = os.path.join(base, "rete_xi.pt")
    path_forza = os.path.join(base, "rete_forza.pt")

    print("=" * 90)
    print(" SOSPENSIONE 2 GDL (PEUGEOT 207) — CONTROLLO APPRESO (ML), REGOLA √2")
    print(f" omega_n = {auto.puls_nat_cassa:.2f} rad/s ({auto.puls_nat_cassa/(2*np.pi):.2f} Hz)"
          f"   |   crossover a r = √2 ≈ {RADQ2:.3f}")
    print("=" * 90)

    device, n_core = rileva_hardware(cfg)

    # 1-2) dati + etichette + finestre
    print("\n[1] Caricamento tracce e generazione etichette (parallela sui core)...")
    tracce_tr, tracce_va = carica_tracce(cfg)
    az_tr, v_tr, y_xi_tr, y_f_tr, r_tr, comfort_tr = costruisci_finestre(tracce_tr, auto, cfg, n_core)
    az_va, v_va, y_xi_va, y_f_va, r_va, comfort_va = costruisci_finestre(tracce_va, auto, cfg, n_core)
    print(f"    Campioni TRAIN : {len(az_tr)}  (2 tracce)")
    print(f"    Campioni VALID : {len(az_va)}  (3a traccia, mai vista)")

    # 3) NORMALIZZAZIONE calcolata SOLO dal training (media/dev-std che emergono dai dati)
    norm = Normalizzatore(az_tr, v_tr)
    print(f"    Normalizzazione (dai dati di training): {norm}")

    def su_device(a):
        return torch.tensor(a, dtype=torch.float32, device=device)

    # ingressi normalizzati + target scalati sui limiti fisici (xi->range damper, forza->F_max)
    AZ_tr = su_device(norm.na(az_tr)).unsqueeze(1); V_tr = su_device(norm.nv(v_tr)).unsqueeze(1)
    XI_tr = su_device(xi_a_norm(y_xi_tr, auto)).unsqueeze(1); F_tr = su_device(forza_a_norm(y_f_tr, cfg)).unsqueeze(1)
    AZ_va = su_device(norm.na(az_va)).unsqueeze(1); V_va = su_device(norm.nv(v_va)).unsqueeze(1)
    XI_va = su_device(xi_a_norm(y_xi_va, auto)).unsqueeze(1); F_va = su_device(forza_a_norm(y_f_va, cfg)).unsqueeze(1)

    # 4) DUE reti separate, loss e optimizer indipendenti
    print("\n[2] Addestramento DUE reti separate (loss e optimizer indipendenti)...")
    rete_xi, rete_forza = crea_reti(cfg)
    rete_xi.to(device); rete_forza.to(device)
    opt_xi = optim.AdamW(rete_xi.parameters(), lr=1e-3, weight_decay=1e-4)
    opt_forza = optim.AdamW(rete_forza.parameters(), lr=1e-3, weight_decay=1e-4)
    loss_xi = nn.HuberLoss(delta=0.25)     # robusta agli outlier per xi
    loss_forza = nn.MSELoss()

    Ntr, Nva, bs = AZ_tr.size(0), AZ_va.size(0), cfg.batch

    def loss_val(rete, target, criterio):
        rete.eval(); s = 0.0
        with torch.no_grad():
            for i in range(0, Nva, bs):
                nb = min(bs, Nva - i)
                s += criterio(rete(AZ_va[i:i+bs], V_va[i:i+bs]), target[i:i+bs]).item() * nb
        return s / Nva

    best_xi = best_f = float("inf")
    for epoca in range(1, cfg.n_epoche + 1):
        rete_xi.train(); rete_forza.train()
        perm = torch.randperm(Ntr, device=device)
        tl_xi = tl_f = 0.0
        for i in range(0, Ntr, bs):
            idx = perm[i:i+bs]; az = AZ_tr[idx]; v = V_tr[idx]
            opt_xi.zero_grad(); lx = loss_xi(rete_xi(az, v), XI_tr[idx]); lx.backward(); opt_xi.step()
            opt_forza.zero_grad(); lf = loss_forza(rete_forza(az, v), F_tr[idx]); lf.backward(); opt_forza.step()
            tl_xi += lx.item() * idx.size(0); tl_f += lf.item() * idx.size(0)
        tl_xi /= Ntr; tl_f /= Ntr
        vl_xi = loss_val(rete_xi, XI_va, loss_xi); vl_f = loss_val(rete_forza, F_va, loss_forza)
        if vl_xi < best_xi:
            best_xi = vl_xi; torch.save(rete_xi.state_dict(), path_xi)
        if vl_f < best_f:
            best_f = vl_f; torch.save(rete_forza.state_dict(), path_forza)
        if epoca % 5 == 0 or epoca == 1:
            print(f"    Epoca {epoca:02d}/{cfg.n_epoche}"
                  f"  |  RETE xi:    Loss(train)={tl_xi:.5f}  Loss(val)={vl_xi:.5f}"
                  f"  |  RETE forza: Loss(train)={tl_f:.5f}  Loss(val)={vl_f:.5f}")

    # 5) valutazione su traccia isolata
    def predici(rete, path):
        rete.load_state_dict(torch.load(path, map_location=device)); rete.eval()
        out = []
        with torch.no_grad():
            for i in range(0, Nva, bs):
                out.append(rete(AZ_va[i:i+bs], V_va[i:i+bs]).cpu())
        return torch.cat(out).numpy().flatten()

    xi_pred = norm_a_xi(predici(rete_xi, path_xi), auto)
    forza_pred = norm_a_forza(predici(rete_forza, path_forza), cfg)

    print("\n" + "=" * 90)
    print(" VALIDAZIONE SU TRACCIA ISOLATA (mai vista)")
    print("=" * 90)
    print(f" xi(t)    -> R^2: {r2_score(y_xi_va, xi_pred):.4f} | MAE: {mean_absolute_error(y_xi_va, xi_pred):.4f}")
    print(f" forza(t) -> R^2: {r2_score(y_f_va, forza_pred):.4f} | MAE: {mean_absolute_error(y_f_va, forza_pred):.1f} N")
    print(f" |forza| max prevista dal ML: {np.abs(forza_pred).max():.1f} N  (limite {cfg.forza_max:.0f} N)")

    # comfort IDEALE (riferimento fisico) e comfort REALE del ML in CLOSED-LOOP
    rms_pas_id = np.mean([p for p, o in (comfort_tr + comfort_va)])
    rms_ideale = np.mean([o for p, o in (comfort_tr + comfort_va)])
    az_val, v_val = tracce_va[0]
    nseg = min(len(az_val), int(cfg.comfort_secondi * cfg.freq_campion))
    traj_cl = traiettorie_reali_ml(az_val[:nseg], v_val[:nseg], rete_xi, rete_forza, norm, auto, cfg, device)
    rms_pas = float(np.sqrt(np.mean(traj_cl["acc_cassa_pas"] ** 2)))
    rms_ml = float(np.sqrt(np.mean(traj_cl["acc_cassa_ml"] ** 2)))
    print(f"\n Comfort CLOSED-LOOP (valori del ML, {nseg/cfg.freq_campion:.0f} s):")
    print(f"   passiva {rms_pas:.3f} m/s^2  ->  ML {rms_ml:.3f} m/s^2  ({100*(1-rms_ml/rms_pas):.1f}% meglio)")
    print(f"   [riferimento ideale fisico: {100*(1-rms_ideale/rms_pas_id):.1f}%]")

    # tabella regola √2
    print("\n" + "-" * 66)
    print(" REGOLA √2: xi in funzione del rapporto r = omega/omega_n (target validazione)")
    print("-" * 66)
    bins = [0.0, 1.0, RADQ2, 2.0, 10.0]
    etich = ["r<1", "1<r<√2", "√2<r<2", "r>2"]
    print(f"{'Range r':<10} | {'v [km/h]':<9} | {'xi medio':<9} | {'kp [Ns/m]':<10} | {'|forza| [N]'}")
    for i in range(len(bins) - 1):
        m = (r_va >= bins[i]) & (r_va < bins[i + 1])
        if np.any(m):
            print(f"{etich[i]:<10} | {v_va[m].mean()*3.6:<9.1f} | {y_xi_va[m].mean():<9.3f} | "
                  f"{kp_da_r(r_va[m].mean(), cfg):<10.0f} | {np.abs(y_f_va[m]).mean():.0f}")

    # 6) figura + animazione
    if cfg.salva_figura:
        salva_figura(y_xi_va, xi_pred, y_f_va, forza_pred, r_va, rms_pas, rms_ml, cfg, auto,
                     os.path.join(base, cfg.figura_file))
    if cfg.mostra_anim or cfg.salva_video:
        print("\n[3] Animazione confronto (controllo dai valori ML)...")
        if cfg.anim_usa_ml:
            traj = traiettorie_demo_ml(rete_xi, rete_forza, norm, auto, cfg, device)
        else:
            traj = traiettorie_demo_ml(rete_xi, rete_forza, norm, auto, cfg, device)
        anima_confronto(traj, cfg, os.path.join(base, cfg.video_file))

    print("=" * 90)
    print(f"Completato in {time.time() - t0:.1f} s")


if __name__ == "__main__":
    main()
