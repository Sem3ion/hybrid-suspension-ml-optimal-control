# -*- coding: utf-8 -*-
"""
ML-2  —  SOSPENSIONE QUARTER-CAR 2 GDL (PEUGEOT 207)
    ξ e kp ATTUATORE ADATTIVI ALLA VELOCITÀ (regola della trasmissibilità √2·ωn)
================================================================================
Idea fisica (base-excitation, trasmissibilità SDOF):
Tutte le curve di trasmissibilità passano per il punto comune a r = ω/ωn = √2.
  * per  ω < √2·ωn  -> più smorzamento MIGLIORA il comfort  =>  ξ ALTO
  * per  ω > √2·ωn  -> più smorzamento PEGGIORA il comfort  =>  ξ BASSO (isolamento)
La frequenza di eccitazione ω cresce con la velocità di traslazione v
(ω = 2π·v/λ_c), quindi ξ e il guadagno attuatore kp diventano funzioni di v:
  * bassa v  (ω<√2ωn):  ξ alto (il damper controlla),  kp basso
  * alta  v  (ω>√2ωn):  ξ basso (damper morbido, isola),  kp alto: l'ATTUATORE fa
                        da buffer skyhook e tiene fermo il "cielo" della cassa con
                        poca forza, SENZA la penalità di trasmissibilità del damper.

Equazioni del moto (corsa x = z_s - z_u ,  v_rel = zs' - zu'):
    m_s * z_s'' = -k_s*x - c(t)*v_rel + F_att
    m_u * z_u'' = +k_s*x + c(t)*v_rel - F_att - k_t*(z_u - z_r)

Attuatore skyhook (tiene ferma la cassa):  F_att = -kp(v) * zs'   (saturato a ±F_max)
=> forza sulla cassa = -c(t)*v_rel - kp(v)*zs'.  Con ruota lenta (zu'~0) v_rel~zs':
        m_s*z_s'' = -k_s*x - ( c(t) + kp(v) ) * zs'      <-- il termine (c(t)+kp)·x'

Pipeline:
  1. Da ogni traccia reale (IMU a_z + GPS v) si ricostruisce il profilo strada z_r(t).
  2. Simulazione 2 GDL in anello chiuso -> target ξ(t) e F_att(t) (forza finita).
  3. CNN 1D addestrata su 2 tracce, VALIDATA sulla 3ª (mai vista).
"""

import os
import glob
import pickle
import time
import warnings
from dataclasses import dataclass

import numpy as np
import scipy.signal as signal
from sklearn.metrics import r2_score, mean_absolute_error

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

warnings.filterwarnings("ignore")

SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)


# =====================================================================
# 1. PARAMETRI FISICI
# =====================================================================
@dataclass
class QuarterCar2DOF:
    """Parametri sospensione anteriore Peugeot 207 (classe ISO B/C)."""
    m_s: float = 260.0        # Massa sospesa (cassa)          [kg]
    m_u: float = 38.0         # Massa non sospesa (ruota)      [kg]
    k_s: float = 23000.0      # Rigidezza molla                [N/m]
    k_t: float = 190000.0     # Rigidezza pneumatico           [N/m]
    c_min: float = 800.0      # Smorzamento min (damper)       [Ns/m]
    c_max: float = 3200.0     # Smorzamento max (damper)       [Ns/m]
    c_nom: float = 1500.0     # Smorzamento passivo (baseline) [Ns/m]

    @property
    def wn(self) -> float:
        """Pulsazione naturale della cassa: sqrt(k_s/m_s)."""
        return np.sqrt(self.k_s / self.m_s)

    @property
    def c_crit(self) -> float:
        """Smorzamento critico della cassa: 2*sqrt(k_s*m_s) = 2*m_s*wn."""
        return 2.0 * np.sqrt(self.k_s * self.m_s)

    def c_to_xi(self, c):
        return c / self.c_crit

    def xi_to_c(self, xi):
        return xi * self.c_crit


@dataclass
class Config:
    fs: float = 100.0         # Frequenza di controllo/campionamento  [Hz]
    dt: float = 0.01          # Passo temporale                        [s]
    n_sub: int = 2            # Sotto-passi RK4 per stabilità
    seq_len: int = 100        # Finestra di memoria per la CNN (1.0 s > periodo cassa 0.67 s)
    freq_win: int = 100       # Finestra per la stima di ω istantanea (1.0 s)

    F_max: float = 1500.0     # Saturazione forza attuatore   [N]  (NO forza infinita)
    road_rms: float = 0.010   # RMS strada nominale prima della calibrazione [m]
    calibra_ampiezza: bool = True  # Calibra z_r per traccia -> forze in Newton fisici

    # --- Scheduling adattivo (regola √2·ωn) sul rapporto r = ω/ωn ---
    # ω è la frequenza di eccitazione stimata istante per istante (strada + velocità).
    sched_steep: float = 4.0  # Ripidità della transizione attorno a r = √2
    xi_hi: float = 0.60       # ξ per ω < √2·ωn : comfort/controllo
    xi_lo: float = 0.18       # ξ per ω > √2·ωn : isolamento
    kp_lo: float = 200.0      # Guadagno attuatore per ω < √2·ωn   [Ns/m]
    kp_hi: float = 2500.0     # Guadagno attuatore per ω > √2·ωn   [Ns/m]
    r_clip: float = 5.0       # Clip di r = ω/ωn per robustezza
    v_cross: float = 13.0     # Solo per riferimento nei grafici (ω=√2ωn ~ 47 km/h)

    epochs: int = 12          # reti separate -> nessun peso di bilanciamento loss
    batch_size: int = 256     # batch più grandi = meno overhead su GPU/MPS
    usa_gpu: bool = True       # usa MPS (Apple Silicon) / CUDA se disponibili
    n_core_override: int = -1  # -1 = auto (solo performance core); >0 = forza N core
    save_fig: bool = True

    # Animazione confronto CON vs SENZA intervento
    show_anim: bool = True
    anim_strada_demo: bool = True # True: strada dimostrativa con dossi (effetto ben visibile)
                                  # False: usa la traccia reale di validazione
    anim_seconds: float = 8.0     # durata simulata da animare [s]
    anim_v: float = 7.0           # velocità di avanzamento nella demo [m/s]
    anim_gain: float = 6.0        # ingrandimento verticale del movimento (resa grafica)
    anim_step: int = 2            # sotto-campionamento frame
    anim_fps: int = 24            # fps del video (più basso = scorrimento più lento)
    anim_mostra: bool = True      # apre la finestra interattiva Python (plt.show())
    anim_save_video: bool = True  # salva anche il video MP4 (richiede ffmpeg)
    anim_video_file: str = "confronto_sospensione.mp4"
    anim_usa_ml: bool = True      # True: usa ξ e F_att PREDETTI dal ML (non i target fisici)
    comfort_ml_seconds: float = 60.0  # durata del segmento su cui misurare il comfort ML (closed-loop)


CAR = QuarterCar2DOF()
CFG = Config()

XI_MIN = CAR.c_to_xi(CAR.c_min)   # ~0.164
XI_MAX = CAR.c_to_xi(CAR.c_max)   # ~0.654


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


SQRT2 = np.sqrt(2.0)


def xi_of_r(r, cfg: Config):
    """ξ alto per r=ω/ωn < √2, basso per r > √2. Transizione al crossover √2."""
    z = cfg.sched_steep * (r / SQRT2 - 1.0)
    return cfg.xi_lo + (cfg.xi_hi - cfg.xi_lo) * _sigmoid(-z)


def kp_of_r(r, cfg: Config):
    """Guadagno attuatore basso per r<√2, alto per r>√2 (buffer skyhook)."""
    z = cfg.sched_steep * (r / SQRT2 - 1.0)
    return cfg.kp_lo + (cfg.kp_hi - cfg.kp_lo) * _sigmoid(z)


def stima_omega(az, cfg: Config):
    """
    Frequenza di eccitazione istantanea ω(t) [rad/s] = frequenza media (Rice) di a_z:
        ω = RMS_finestra(a_z) / RMS_finestra(v_z),   v_z = integrale singolo di a_z.
    Per a_z = A·sin(ωt) restituisce esattamente ω. Usa UNA sola integrazione (v_z,
    passa-alto) -> nessun bias verso le basse frequenze. Scala-invariante (rapporto):
    non dipende dall'ampiezza, cresce con velocità E rugosità -> ξ adattivo alla strada.
    """
    fs = cfg.fs
    nyq = 0.5 * fs
    b, a = signal.butter(2, 0.3 / nyq, btype="highpass")
    vz = signal.filtfilt(b, a, np.cumsum(az) / fs)     # velocità (una integrazione)
    w = cfg.freq_win
    ker = np.ones(w) / w
    mrms = lambda s: np.sqrt(np.convolve(s * s, ker, mode="same") + 1e-12)
    omega = mrms(az) / (mrms(vz) + 1e-9)
    wn = np.sqrt(CAR.k_s / CAR.m_s)
    return np.clip(omega, 0.15 * wn, cfg.r_clip * wn)


# =====================================================================
# 2. RICOSTRUZIONE PROFILO STRADA DA a_z
# =====================================================================
def rimuovi_dc_offset(az, fs=100.0, fc=0.1):
    nyq = 0.5 * fs
    b, a = signal.butter(2, fc / nyq, btype="highpass")
    return signal.filtfilt(b, a, az)


def ricostruisci_strada(az, cfg: Config):
    """Doppia integrazione anti-windup di a_z -> profilo strada z_r(t), z_r'(t)."""
    fs = cfg.fs
    nyq = 0.5 * fs
    b, a = signal.butter(2, 0.3 / nyq, btype="highpass")
    vz = signal.filtfilt(b, a, np.cumsum(az) / fs)
    zr = signal.filtfilt(b, a, np.cumsum(vz) / fs)
    rms = np.sqrt(np.mean(zr ** 2)) + 1e-9
    zr = zr * (cfg.road_rms / rms)
    zr_dot = np.gradient(zr, cfg.dt)
    return zr.astype(float), zr_dot.astype(float)


# =====================================================================
# 3. MODELLO DINAMICO 2 GDL E INTEGRATORE RK4
# =====================================================================
# Stato x = [ z_s-z_u , zs' , z_u-z_r , zu' ]
def _deriv(x, c, F_att, zr_dot, car):
    ms, mu, ks, kt = car.m_s, car.m_u, car.k_s, car.k_t
    x1, x2, x3, x4 = x
    v_rel = x2 - x4
    dx1 = x2 - x4
    dx2 = (-ks * x1 - c * v_rel + F_att) / ms
    dx3 = x4 - zr_dot
    dx4 = (ks * x1 + c * v_rel - F_att - kt * x3) / mu
    return np.array([dx1, dx2, dx3, dx4])


def _rk4_step(x, c, F_att, zr0, zr1, car, h):
    zm = 0.5 * (zr0 + zr1)
    k1 = _deriv(x,            c, F_att, zr0, car)
    k2 = _deriv(x + 0.5*h*k1, c, F_att, zm,  car)
    k3 = _deriv(x + 0.5*h*k2, c, F_att, zm,  car)
    k4 = _deriv(x + h*k3,     c, F_att, zr1, car)
    return x + (h / 6.0) * (k1 + 2*k2 + 2*k3 + k4)


# =====================================================================
# 4. GENERATORE DI TARGET (ξ ADATTIVO ALLA STRADA √2 + ATTUATORE SKYHOOK)
# =====================================================================
def _passive_rms(zr_dot, car, cfg):
    """RMS dell'accelerazione cassa del modello PASSIVO (c_nom) -> per calibrazione."""
    N = len(zr_dot)
    xp = np.zeros(4)
    h = cfg.dt / cfg.n_sub
    acc = 0.0
    for k in range(N):
        acc += (-car.k_s * xp[0] - car.c_nom * (xp[1] - xp[3])) ** 2
        zr0 = zr_dot[k]
        zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
        for _ in range(cfg.n_sub):
            xp = _rk4_step(xp, car.c_nom, 0.0, zr0, zr1, car, h)
    return np.sqrt(acc / N) / car.m_s


class PhysicsAdaptiveTargetGenerator:
    def __init__(self, car: QuarterCar2DOF, cfg: Config):
        self.car = car
        self.cfg = cfg

    def generate(self, az_clean, v_interp):
        cfg, car = self.cfg, self.car
        N = len(az_clean)
        zr, zr_dot = ricostruisci_strada(az_clean, cfg)

        # --- Calibrazione ampiezza strada: il modello passivo deve riprodurre
        #     l'RMS dell'a_z MISURATO -> forze attuatore in Newton fisici ---
        if cfg.calibra_ampiezza:
            rms_meas = np.sqrt(np.mean(az_clean ** 2))
            rms_pas0 = _passive_rms(zr_dot, car, cfg)
            factor = np.clip(rms_meas / (rms_pas0 + 1e-9), 0.2, 20.0)
            zr = zr * factor
            zr_dot = zr_dot * factor

        # --- Frequenza di eccitazione istantanea -> r = ω/ωn (strada + velocità) ---
        omega = stima_omega(az_clean, cfg)       # da a_z (scala-invariante)
        r_arr = omega / car.wn
        xi_arr = xi_of_r(r_arr, cfg)
        kp_arr = kp_of_r(r_arr, cfg)
        c_arr = car.xi_to_c(xi_arr)

        xi_t = xi_arr.astype(np.float32)
        kp_t = kp_arr.astype(np.float32)
        F_t = np.zeros(N, dtype=np.float32)
        az_opt = np.zeros(N, dtype=np.float32)
        az_pas = np.zeros(N, dtype=np.float32)

        x = np.zeros(4)      # ramo controllato
        xp = np.zeros(4)     # ramo passivo
        h = cfg.dt / cfg.n_sub

        for k in range(N):
            c = c_arr[k]
            kp = kp_arr[k]
            zs_dot = x[1]                        # velocità assoluta cassa
            v_rel = x[1] - x[3]
            F_att = np.clip(-kp * zs_dot, -cfg.F_max, cfg.F_max)   # skyhook, forza finita

            F_t[k] = F_att
            az_opt[k] = (-car.k_s * x[0] - c * v_rel + F_att) / car.m_s
            az_pas[k] = (-car.k_s * xp[0] - car.c_nom * (xp[1] - xp[3])) / car.m_s

            zr0 = zr_dot[k]
            zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
            for _ in range(cfg.n_sub):
                x = _rk4_step(x, c, F_att, zr0, zr1, car, h)
                xp = _rk4_step(xp, car.c_nom, 0.0, zr0, zr1, car, h)

        return dict(xi=xi_t, F=F_t, kp=kp_t, r=r_arr.astype(np.float32),
                    az_opt=az_opt, az_pas=az_pas, zr=zr, N=N)


# =====================================================================
# 5. DATASET: 2 TRACCE TRAIN / 3ª VALIDAZIONE
# =====================================================================
def carica_tracce():
    try:
        import kagglehub
        cartella = kagglehub.dataset_download("nickkotarelas/road-quality-dataset")
        files = sorted(glob.glob(os.path.join(cartella, "**", "*.pkl"), recursive=True))
    except Exception:
        files = []

    tr, va = [], []

    if len(files) >= 3:
        files_tr, files_va = files[:-1], [files[-1]]
        print(f"  [ok] {len(files)} tracce reali -> {len(files_tr)} train / 1 validazione ({os.path.basename(files_va[0])})")
        for grp, dst in ((files_tr, tr), (files_va, va)):
            for pkl in grp:
                with open(pkl, "rb") as f:
                    d = pickle.load(f)
                imu = d["imu"]
                t_imu = np.array(imu["time"]["rel"], dtype=float)
                medie = {kk: abs(np.mean(vv)) for kk, vv in imu["accel"].items()}
                az = rimuovi_dc_offset(np.array(imu["accel"][max(medie, key=medie.get)], dtype=float))
                t_gps = np.array(d["gps"]["time"]["rel"], dtype=float)
                v_gps = np.array(d["gps"]["speed"], dtype=float)
                v = np.interp(t_imu, t_gps, v_gps)
                dst.append((az, v))
    else:
        print("  [!] Dataset reale non disponibile: genero 3 tracce sintetiche distinte (2 train / 1 val).")
        for i in range(3):
            rng = np.random.default_rng(SEED + i)
            N = 9000
            t = np.linspace(0, 90, N)
            base_v = [8.0, 15.0, 26.0][i]     # tracce a regimi di velocità diversi
            v = np.clip(base_v + 7.0 * np.sin(2*np.pi*(0.01 + 0.004*i)*t) + rng.normal(0, 0.2, N), 3.0, 33.0)
            f_road = 0.6 + 0.9 * v / 10.0     # freq. strada cresce con la velocità
            az = np.sin(2*np.pi*f_road*t) * (0.7 + 0.05*v) + rng.normal(0, 0.15, N)
            (tr if i < 2 else va).append((az, v))

    return tr, va


def costruisci_finestre(tracce, gen, cfg: Config, n_workers=0):
    # generazione target: le tracce sono indipendenti -> parallelizzabili sui core
    if n_workers and n_workers > 1 and len(tracce) > 1:
        try:
            import multiprocessing as mp
            ctx = mp.get_context("spawn")
            with ctx.Pool(min(n_workers, len(tracce))) as pool:
                outs = pool.map(_worker_target,
                                [(gen.car, gen.cfg, az, v) for az, v in tracce])
        except Exception as e:
            print(f"    [i] generazione parallela non riuscita ({e}); uso seriale")
            outs = [gen.generate(az, v) for az, v in tracce]
    else:
        outs = [gen.generate(az, v) for az, v in tracce]

    X_az, X_v, Y_xi, Y_F, X_r = [], [], [], [], []
    comfort_stats = []
    for (az, v), out in zip(tracce, outs):
        comfort_stats.append((np.sqrt(np.mean(out["az_pas"]**2)),
                              np.sqrt(np.mean(out["az_opt"]**2))))
        for i in range(cfg.seq_len, out["N"]):
            if v[i] < 2.0:
                continue
            X_az.append(az[i-cfg.seq_len:i])
            X_v.append(v[i])
            Y_xi.append(out["xi"][i])
            Y_F.append(out["F"][i])
            X_r.append(out["r"][i])
    return (np.array(X_az, dtype=np.float32), np.array(X_v, dtype=np.float32),
            np.array(Y_xi, dtype=np.float32), np.array(Y_F, dtype=np.float32),
            np.array(X_r, dtype=np.float32), comfort_stats)


# =====================================================================
# 6. DUE CNN 1D SEPARATE (una per ξ, una per F_att)
# =====================================================================
# Reti indipendenti addestrate con LOSS e OPTIMIZER distinti: nessun accoppiamento,
# nessuna competizione tra i due obiettivi. Attivazioni scelte per compito:
#   - Rete ξ : ReLU  + uscita Sigmoid  (mappa liscia e saturante, compito facile)
#   - Rete F : GELU  + uscita Tanh     (regressione più dura: ricostruisce ż_s dalla
#              finestra a_z; GELU dà gradienti più dolci e niente unità "morte")
class SuspensionDataset(Dataset):
    def __init__(self, X_az, X_v, Y_xi, Y_F):
        self.X_az = torch.tensor(X_az, dtype=torch.float32).unsqueeze(1)
        self.X_v = torch.tensor(X_v, dtype=torch.float32).unsqueeze(1)
        self.Y_xi = torch.tensor(Y_xi, dtype=torch.float32).unsqueeze(1)
        self.Y_F = torch.tensor(Y_F, dtype=torch.float32).unsqueeze(1)

    def __len__(self):
        return len(self.Y_xi)

    def __getitem__(self, i):
        return self.X_az[i], self.X_v[i], self.Y_xi[i], self.Y_F[i]


class SuspCNN1D(nn.Module):
    """
    Backbone 1D-CNN per F_attuattore + 1D-TCN per xi, ISTANZIATO SEPARATAMENTE per ξ e per F_att.
    Input : [ finestra a_z (seq_len, 1 s) , velocità v ]
    act      : classe di attivazione interna (nn.ReLU oppure nn.GELU)
    out_act  : 'sigmoid' -> ξ_norm in (0,1)   |   'tanh' -> F_norm in (-1,1) (forza FINITA)

    Niente AdaptiveAvgPool (che comprimerebbe la dimensione temporale e rischia lo
    'squeeze'): la finestra è FISSA (seq_len), quindi il flatten è deterministico e
    calcolato una volta dalla geometria dei conv/pool.
    """
    def __init__(self, seq_len, act=nn.ReLU, out_act="sigmoid", hidden=128):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=5, padding=2),
            nn.BatchNorm1d(32), act(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64), act(), nn.MaxPool1d(2),
        )
        # dimensione flatten dalla finestra fissa (no adaptive pooling)
        self.conv.eval()
        with torch.no_grad():
            flat = self.conv(torch.zeros(1, 1, seq_len)).flatten(1).size(1)
        self.conv.train()
        self.flat = flat
        self.fc = nn.Sequential(nn.Linear(flat + 1, hidden), act(), nn.Dropout(0.2))
        out = nn.Sigmoid() if out_act == "sigmoid" else nn.Tanh()
        self.head = nn.Sequential(nn.Linear(hidden, 32), act(), nn.Linear(32, 1), out)

    def forward(self, x_az, x_v):
        feat = self.conv(x_az).flatten(1)
        emb = self.fc(torch.cat((feat, x_v), dim=1))
        return self.head(emb)

class SuspTCN1D(nn.Module):
    """
    TCN con interfaccia identica a SuspCNN1D. 
    Usa dilatazioni crescenti (1, 2, 4, 8) per catturare il contesto temporale a lungo raggio.
    """
    def __init__(self, seq_len, act=nn.ReLU, out_act="sigmoid", hidden=128):
        super().__init__()
        self.tcn = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=3, padding=1, dilation=1),
            nn.BatchNorm1d(32), act(),
            nn.Conv1d(32, 32, kernel_size=3, padding=2, dilation=2),
            nn.BatchNorm1d(32), act(),
            nn.Conv1d(32, 64, kernel_size=3, padding=4, dilation=4),
            nn.BatchNorm1d(64), act(),
            nn.Conv1d(64, 64, kernel_size=3, padding=8, dilation=8),
            nn.BatchNorm1d(64), act(),
        )
        
        # Calcolo dinamico del flatten (invariato rispetto alla tua struttura)
        self.tcn.eval()
        with torch.no_grad():
            flat = self.tcn(torch.zeros(1, 1, seq_len)).flatten(1).size(1)
        self.tcn.train()
        
        self.flat = flat
        self.fc = nn.Sequential(nn.Linear(flat + 1, hidden), act(), nn.Dropout(0.2))
        out = nn.Sigmoid() if out_act == "sigmoid" else nn.Tanh()
        self.head = nn.Sequential(nn.Linear(hidden, 32), act(), nn.Linear(32, 1), out)

    def forward(self, x_az, x_v):
        feat = self.tcn(x_az).flatten(1)
        emb = self.fc(torch.cat((feat, x_v), dim=1))
        return self.head(emb)

def crea_reti(cfg):
    """Mette la TCN sul ramo di xi e mantiene la CNN classica sul ramo di F_att."""
    net_xi = SuspTCN1D(cfg.seq_len, act=nn.ReLU, out_act="sigmoid")     # TCN per stima di xi
    net_F  = SuspCNN1D(cfg.seq_len, act=nn.GELU, out_act="tanh")        # CNN per stima di F_attuatore
    return net_xi, net_F


# =====================================================================
# 6b. RILEVAMENTO HARDWARE (GPU/MPS + performance core)
# =====================================================================
def _worker_target(args):
    """Genera i target di UNA traccia (per la parallelizzazione multi-core)."""
    car, cfg, az, v = args
    return PhysicsAdaptiveTargetGenerator(car, cfg).generate(az, v)


def rileva_hardware(cfg: Config):
    """
    Identifica il PC: sceglie il device (MPS su Apple Silicon, altrimenti CUDA, altrimenti
    CPU) e il numero di PERFORMANCE core (salta gli efficiency core su Apple Silicon).
    Ritorna (device, n_core) e imposta i thread torch per la CPU.
    """
    import platform, subprocess
    if cfg.usa_gpu and torch.cuda.is_available():
        device = torch.device("cuda"); dev = "CUDA: " + torch.cuda.get_device_name(0)
    elif cfg.usa_gpu and getattr(torch.backends, "mps", None) is not None \
            and torch.backends.mps.is_available():
        device = torch.device("mps"); dev = "Apple Silicon GPU (MPS)"
    else:
        device = torch.device("cpu"); dev = "CPU"

    perf = eff = None
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        def _sc(k):
            try:
                return int(subprocess.check_output(["sysctl", "-n", k]).decode().strip())
            except Exception:
                return None
        perf = _sc("hw.perflevel0.logicalcpu")   # performance core
        eff = _sc("hw.perflevel1.logicalcpu")    # efficiency core (li saltiamo)

    total = os.cpu_count() or 1
    n_core = perf if perf else total
    if cfg.n_core_override > 0:
        n_core = cfg.n_core_override
    torch.set_num_threads(max(1, n_core))

    print(f"    HW: {dev}")
    if perf:
        print(f"    Core: {total} totali -> uso {n_core} performance (salto {eff} efficiency)")
    else:
        print(f"    Core: uso {n_core} (nessuna distinzione perf/eff)")
    return device, n_core


# =====================================================================
# 7. FIGURA RISULTATI
# =====================================================================
def salva_figura(xi_true, xi_pred, F_true, F_pred, r_va, rms_pas, rms_opt, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as e:
        print(f"    [i] matplotlib non disponibile, salto la figura ({e})")
        return
    fig, ax = plt.subplots(2, 2, figsize=(13, 8))
    fig.suptitle("Sospensione 2 GDL Peugeot 207 — ξ adattivo alla strada + attuatore skyhook (regola √2·ωn)",
                 fontsize=13, fontweight="bold")

    n = min(800, len(xi_true))
    tt = np.arange(n) * CFG.dt
    ax[0, 0].plot(tt, xi_true[:n], "r-", lw=1.0, label="ξ target (fisico)")
    ax[0, 0].plot(tt, xi_pred[:n], "g-", lw=1.0, alpha=0.8, label="ξ CNN")
    ax[0, 0].set_title("ξ(t): smorzamento adattivo"); ax[0, 0].set_xlabel("t [s]"); ax[0, 0].set_ylabel("ξ")
    ax[0, 0].legend(fontsize=8); ax[0, 0].grid(alpha=0.3)

    ax[0, 1].plot(tt, F_true[:n], "r-", lw=1.0, label="F_att target")
    ax[0, 1].plot(tt, F_pred[:n], "b-", lw=1.0, alpha=0.8, label="F_att CNN")
    ax[0, 1].axhline(CFG.F_max, ls=":", c="k"); ax[0, 1].axhline(-CFG.F_max, ls=":", c="k")
    ax[0, 1].set_title("F_att(t): attuatore skyhook (saturato ±F_max)")
    ax[0, 1].set_xlabel("t [s]"); ax[0, 1].set_ylabel("F [N]")
    ax[0, 1].legend(fontsize=8); ax[0, 1].grid(alpha=0.3)

    # ξ e kp in funzione di r = ω/ωn : il grafico chiave della regola √2
    rr = np.linspace(0.3, 4.0, 200)
    axL = ax[1, 0]
    sub = np.random.default_rng(0).choice(len(r_va), size=min(3000, len(r_va)), replace=False)
    axL.scatter(r_va[sub], xi_true[sub], s=3, alpha=0.15, c="orange", label="target (strada reale)")
    axL.plot(rr, xi_of_r(rr, CFG), "-", c="darkred", lw=2, label="legge ξ(r)")
    axL.axvline(SQRT2, ls="--", c="k", alpha=0.7); axL.text(SQRT2 + 0.05, 0.57, "r = √2", fontsize=9)
    axL.text(0.5, 0.57, "ξ alto\n(comfort)", fontsize=8, color="darkred")
    axL.text(3.0, 0.21, "ξ basso\n(isolamento)", fontsize=8, color="darkred")
    axL.set_xlabel("r = ω/ωn"); axL.set_ylabel("ξ", color="darkred"); axL.grid(alpha=0.3)
    axL.legend(fontsize=7, loc="center right")
    axR = axL.twinx()
    axR.plot(rr, kp_of_r(rr, CFG), "-", c="teal", lw=2)
    axR.set_ylabel("kp attuatore [Ns/m]", color="teal")
    axL.set_title("ξ e kp vs frequenza di eccitazione r = ω/ωn")

    ax[1, 1].bar(["passiva\n(c_nom)", "controllata\n(ML: ξ+F_att)"], [rms_pas, rms_opt],
                 color=["gray", "seagreen"])
    ax[1, 1].set_title(f"RMS accel. cassa (comfort, valori ML)  —  {100*(1-rms_opt/rms_pas):.0f}% meglio")
    ax[1, 1].set_ylabel("RMS a_z [m/s²]"); ax[1, 1].grid(alpha=0.3, axis="y")

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(path, dpi=120)
    print(f"    [ok] Figura salvata: {os.path.basename(path)}")


# =====================================================================
# 7b. ANIMAZIONE CONFRONTO: CON vs SENZA INTERVENTO
# =====================================================================
def _simula_rami(zr, zr_dot, xi_arr, v_slice, car: QuarterCar2DOF, cfg: Config,
                 kp_arr=None, F_series=None):
    """
    Integra i DUE rami (controllato + passivo c_nom) sullo STESSO profilo strada e
    registra le traiettorie ASSOLUTE z_s, z_u.
    Controllo del ramo attivo:
      - se F_series è dato -> usa la FORZA PREDETTA DAL ML (open-loop, saturata);
      - altrimenti -> skyhook fisico F_att = -kp(v)·zs'.
    ξ_arr può essere la legge fisica xi_of_r OPPURE la ξ predetta dal ML.
    """
    N = len(zr)
    c_arr = car.xi_to_c(xi_arr)
    zs_c = np.zeros(N); zu_c = np.zeros(N); zs_p = np.zeros(N); zu_p = np.zeros(N)
    F = np.zeros(N); az_c = np.zeros(N); az_p = np.zeros(N)
    x = np.zeros(4); xp = np.zeros(4)
    h = cfg.dt / cfg.n_sub
    for k in range(N):
        c = c_arr[k]
        zu_c[k] = x[2] + zr[k]; zs_c[k] = x[0] + zu_c[k]
        zu_p[k] = xp[2] + zr[k]; zs_p[k] = xp[0] + zu_p[k]
        if F_series is not None:
            F_att = float(np.clip(F_series[k], -cfg.F_max, cfg.F_max))      # forza dal ML
        else:
            F_att = float(np.clip(-kp_arr[k] * x[1], -cfg.F_max, cfg.F_max))  # skyhook fisico
        F[k] = F_att
        az_c[k] = (-car.k_s * x[0] - c * (x[1] - x[3]) + F_att) / car.m_s
        az_p[k] = (-car.k_s * xp[0] - car.c_nom * (xp[1] - xp[3])) / car.m_s
        zr0 = zr_dot[k]; zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
        for _ in range(cfg.n_sub):
            x = _rk4_step(x, c, F_att, zr0, zr1, car, h)
            xp = _rk4_step(xp, car.c_nom, 0.0, zr0, zr1, car, h)
    x_pos = np.cumsum(np.maximum(v_slice, 0.0) * cfg.dt)
    return dict(zr=zr, zs_c=zs_c, zu_c=zu_c, zs_p=zs_p, zu_p=zu_p, F=F,
                xi=xi_arr.astype(np.float32), az_c=az_c, az_p=az_p, x_pos=x_pos, N=N)


def simula_traiettorie(az_slice, v_slice, car: QuarterCar2DOF, cfg: Config):
    """Traiettorie per l'animazione a partire dalla traccia reale (a_z + v)."""
    zr, zr_dot = ricostruisci_strada(az_slice, cfg)
    if cfg.calibra_ampiezza:
        rms_meas = np.sqrt(np.mean(az_slice ** 2))
        factor = np.clip(rms_meas / (_passive_rms(zr_dot, car, cfg) + 1e-9), 0.2, 20.0)
        zr = zr * factor; zr_dot = zr_dot * factor
    r_arr = stima_omega(az_slice, cfg) / car.wn
    return _simula_rami(zr, zr_dot, xi_of_r(r_arr, cfg), v_slice, car, cfg,
                        kp_arr=kp_of_r(r_arr, cfg))


def simula_demo(car: QuarterCar2DOF, cfg: Config):
    """
    Strada DIMOSTRATIVA: fondo liscio con dossi periodici a velocità costante, con
    contenuto attorno alla risonanza (r~√2) dove l'effetto è massimo. La ruota segue
    i dossi mentre la cassa attiva resta ferma e quella passiva sobbalza.
    """
    N = int(cfg.anim_seconds * cfg.fs)
    t = np.arange(N) * cfg.dt
    v0 = cfg.anim_v
    v = np.full(N, v0)
    x_pos = np.cumsum(v * cfg.dt)
    L = v0 / 1.6                       # spaziatura dossi -> ~1.6 Hz (banda risonanza)
    zr = np.zeros(N)
    for xb in np.arange(4.0, x_pos[-1], L):
        zr += 0.035 * np.exp(-((x_pos - xb) ** 2) / (2 * 0.45 ** 2))
    zr += 0.002 * np.sin(2 * np.pi * 2.5 * t)     # texture leggera
    zr_dot = np.gradient(zr, cfg.dt)
    # ω dal profilo strada (RMS_win(zr') / RMS_win(zr))
    w = cfg.freq_win; ker = np.ones(w) / w
    mrms = lambda s: np.sqrt(np.convolve(s * s, ker, mode="same") + 1e-12)
    omega = np.clip(mrms(zr_dot) / (mrms(zr) + 1e-9), 0.15 * car.wn, cfg.r_clip * car.wn)
    r_arr = omega / car.wn
    return _simula_rami(zr, zr_dot, xi_of_r(r_arr, cfg), v, car, cfg, kp_arr=kp_of_r(r_arr, cfg))


# =====================================================================
# 7c. SIMULAZIONE CON I VALORI PREDETTI DAL ML (non i target fisici)
# =====================================================================
def _az_passivo(zr, zr_dot, car: QuarterCar2DOF, cfg: Config):
    """Accelerazione cassa del veicolo PASSIVO su un profilo strada (il 'sensore' che legge il ML)."""
    N = len(zr); xp = np.zeros(4); az = np.zeros(N); h = cfg.dt / cfg.n_sub
    for k in range(N):
        az[k] = (-car.k_s * xp[0] - car.c_nom * (xp[1] - xp[3])) / car.m_s
        zr0 = zr_dot[k]; zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
        for _ in range(cfg.n_sub):
            xp = _rk4_step(xp, car.c_nom, 0.0, zr0, zr1, car, h)
    return az


def predici_serie(net_xi, net_F, az, v, device, cfg: Config):
    """
    Scorre le finestre di a_z e restituisce le SERIE TEMPORALI predette dal ML,
    ξ(t) in [ξ_min,ξ_max] e F_att(t) in [-F_max,F_max], denormalizzate e allineate ad az.
    """
    from numpy.lib.stride_tricks import sliding_window_view
    N = len(az); seq = cfg.seq_len
    xi_series = np.empty(N, np.float32); F_series = np.empty(N, np.float32)
    if N <= seq:
        xi_series[:] = XI_MIN; F_series[:] = 0.0
        return xi_series, F_series
    W = sliding_window_view(az.astype(np.float32), seq)[:N - seq]   # riga j -> target seq+j
    Vt = v[seq:N].astype(np.float32)
    xi_p = np.empty(N - seq, np.float32); F_p = np.empty(N - seq, np.float32)
    bs = cfg.batch_size
    net_xi.eval(); net_F.eval()
    with torch.no_grad():
        for b in range(0, N - seq, bs):
            azt = torch.tensor(np.ascontiguousarray(W[b:b+bs]), device=device).unsqueeze(1)
            vt = torch.tensor(Vt[b:b+bs], device=device).unsqueeze(1)
            xi_p[b:b+bs] = net_xi(azt, vt).cpu().numpy().ravel()
            F_p[b:b+bs] = net_F(azt, vt).cpu().numpy().ravel()
    xi_series[seq:] = XI_MIN + xi_p * (XI_MAX - XI_MIN)
    F_series[seq:] = F_p * cfg.F_max
    xi_series[:seq] = xi_series[seq]; F_series[:seq] = F_series[seq]
    return xi_series, F_series


def simula_rami_closed_loop(zr, zr_dot, v_slice, net_xi, net_F, device, car: QuarterCar2DOF, cfg: Config):
    """
    CLOSED-LOOP VERO (come nella realtà): a ogni passo la rete legge la finestra degli
    ultimi seq_len campioni di a_z della cassa CONTROLLATA (feedback dell'accelerometro),
    predice ξ e F_att e li APPLICA al passo corrente. La strada z_r è il disturbo; il
    ramo passivo (c_nom) gira in parallelo come baseline. All'avvio (k<seq_len) la
    finestra è riempita con zero-padding a sinistra.
    """
    N = len(zr); seq = cfg.seq_len; h = cfg.dt / cfg.n_sub
    ccrit = car.c_crit
    zs_c = np.zeros(N); zu_c = np.zeros(N); zs_p = np.zeros(N); zu_p = np.zeros(N)
    F = np.zeros(N); xi = np.zeros(N, np.float32)
    az_c = np.zeros(N, np.float32); az_p = np.zeros(N)
    x = np.zeros(4); xp = np.zeros(4)
    net_xi.eval(); net_F.eval()
    win = np.zeros(seq, np.float32)
    with torch.no_grad():
        for k in range(N):
            # finestra causale sugli a_z GIÀ misurati della cassa controllata
            if k >= seq:
                w = az_c[k-seq:k]
            else:
                win[:] = 0.0
                if k > 0:
                    win[seq-k:] = az_c[:k]
                w = win
            azt = torch.as_tensor(w, dtype=torch.float32, device=device).view(1, 1, seq)
            vt = torch.tensor([[float(v_slice[k])]], dtype=torch.float32, device=device)
            xi_k = XI_MIN + float(net_xi(azt, vt)) * (XI_MAX - XI_MIN)
            F_k = float(net_F(azt, vt)) * cfg.F_max
            c = xi_k * ccrit
            F_att = float(np.clip(F_k, -cfg.F_max, cfg.F_max))
            xi[k] = xi_k; F[k] = F_att

            zu_c[k] = x[2] + zr[k]; zs_c[k] = x[0] + zu_c[k]
            zu_p[k] = xp[2] + zr[k]; zs_p[k] = xp[0] + zu_p[k]
            az_c[k] = (-car.k_s * x[0] - c * (x[1] - x[3]) + F_att) / car.m_s
            az_p[k] = (-car.k_s * xp[0] - car.c_nom * (xp[1] - xp[3])) / car.m_s

            zr0 = zr_dot[k]; zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
            for _ in range(cfg.n_sub):
                x = _rk4_step(x, c, F_att, zr0, zr1, car, h)
                xp = _rk4_step(xp, car.c_nom, 0.0, zr0, zr1, car, h)

    x_pos = np.cumsum(np.maximum(v_slice, 0.0) * cfg.dt)
    return dict(zr=zr, zs_c=zs_c, zu_c=zu_c, zs_p=zs_p, zu_p=zu_p, F=F,
                xi=xi, az_c=az_c, az_p=az_p, x_pos=x_pos, N=N)


def simula_demo_ml(net_xi, net_F, device, car: QuarterCar2DOF, cfg: Config):
    """Strada dimostrativa con dossi, controllo CLOSED-LOOP dai valori del ML."""
    N = int(cfg.anim_seconds * cfg.fs); t = np.arange(N) * cfg.dt
    v0 = cfg.anim_v; v = np.full(N, v0); x_pos = np.cumsum(v * cfg.dt)
    L = v0 / 1.6; zr = np.zeros(N)
    x0 = max(4.0, v0 * cfg.seq_len * cfg.dt + 2.0)   # primo dosso DOPO il warm-up finestra
    for xb in np.arange(x0, x_pos[-1], L):
        zr += 0.035 * np.exp(-((x_pos - xb) ** 2) / (2 * 0.45 ** 2))
    zr += 0.002 * np.sin(2 * np.pi * 2.5 * t); zr_dot = np.gradient(zr, cfg.dt)
    return simula_rami_closed_loop(zr, zr_dot, v, net_xi, net_F, device, car, cfg)


def simula_traiettorie_ml(az_slice, v_slice, net_xi, net_F, device, car: QuarterCar2DOF, cfg: Config):
    """Traccia reale: strada ricostruita da a_z, controllo CLOSED-LOOP dai valori del ML."""
    zr, zr_dot = ricostruisci_strada(az_slice, cfg)
    if cfg.calibra_ampiezza:
        f = np.clip(np.sqrt(np.mean(az_slice ** 2)) / (_passive_rms(zr_dot, car, cfg) + 1e-9), 0.2, 20.0)
        zr = zr * f; zr_dot = zr_dot * f
    return simula_rami_closed_loop(zr, zr_dot, v_slice, net_xi, net_F, device, car, cfg)


# --- Geometria (metri) del quarter-car disegnato, scala realistica ---
_R_W = 0.33          # raggio ruota
_HUB = 0.13          # raggio mozzo
_BODY_W = 1.9        # larghezza cassa
_BODY_H = 0.55       # altezza cassa
_STRUT = 0.42        # luce ruota-cassa a riposo
_BODY_BASE = 2 * _R_W + _STRUT   # quota base cassa a riposo


def _spring_zig(xc, y0, y1, coils=6, width=0.14):
    ys = np.linspace(y0, y1, 2 * coils + 2)
    xs = np.full_like(ys, xc)
    xs[1:-1:2] = xc - width / 2
    xs[2:-1:2] = xc + width / 2
    return xs, ys


def _crea_pannello(ax, colore, titolo):
    from matplotlib.patches import Circle, Rectangle, Polygon
    asfalto = Polygon([[0, 0]], closed=True, fc="0.78", ec="0.35", lw=1.0, zorder=1)
    road, = ax.plot([], [], "-", c="0.15", lw=2.5, zorder=2)
    tire = Circle((0, 0), _R_W, fc="0.15", ec="black", lw=1.5, zorder=5)
    hub = Circle((0, 0), _HUB, fc="0.7", ec="black", lw=1.0, zorder=6)
    body = Rectangle((0, 0), _BODY_W, _BODY_H, fc=colore, ec="black", lw=1.8, alpha=0.92, zorder=5)
    spring, = ax.plot([], [], "-", c="crimson", lw=2.0, zorder=4)
    damper, = ax.plot([], [], "-", c="royalblue", lw=5.0, solid_capstyle="butt", zorder=4)
    ref = ax.axhline(_BODY_BASE + _BODY_H / 2, ls=":", c="green", alpha=0.5, zorder=3)
    txt = ax.text(0.015, 0.96, "", transform=ax.transAxes, fontsize=10, va="top", zorder=8,
                  bbox=dict(boxstyle="round", fc="white", ec="0.6", alpha=0.85))
    ax.add_patch(asfalto); ax.add_patch(tire); ax.add_patch(hub); ax.add_patch(body)
    ax.set_title(titolo, fontsize=12, fontweight="bold")
    ax.set_ylabel("quota [m]")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, ls="--", alpha=0.25)
    return dict(asfalto=asfalto, road=road, tire=tire, hub=hub, body=body,
               spring=spring, damper=damper, ref=ref, txt=txt)


def anima_confronto(traj, cfg: Config, path_video=None, mostra=True):
    """
    Due pannelli impilati: SOPRA con sospensione adattiva + attuatore, SOTTO passiva.
    La ruota (tangente all'asfalto) segue i dossi; con l'intervento la cassa resta
    incollata alla linea verde di riferimento, senza intervento sobbalza.
    Apre una finestra interattiva (plt.show) e salva il video MP4 (serve ffmpeg).
    """
    try:
        import matplotlib
        if not mostra:
            matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.animation as animation
    except Exception as e:
        print(f"    [i] matplotlib/animazione non disponibile ({e})")
        return

    g = cfg.anim_gain
    W = 4.5                        # semi-finestra strada visibile [m]
    step = max(1, cfg.anim_step)
    frames = range(0, traj["N"], step)
    dt = cfg.dt

    x_pos = traj["x_pos"]
    road_y = traj["zr"] * g                        # profilo asfalto amplificato
    body_yc = _BODY_BASE + traj["zs_c"] * g        # base cassa (con intervento)
    body_yp = _BODY_BASE + traj["zs_p"] * g        # base cassa (passivo)

    fig, (axT, axB) = plt.subplots(2, 1, figsize=(12, 8.2), sharex=True)
    fig.suptitle("Peugeot 207 sulla stessa strada con dossi — sospensione adattiva vs passiva",
                 fontsize=13, fontweight="bold")
    A = _crea_pannello(axT, "seagreen", "CON intervento  (ξ adattivo + attuatore skyhook)")
    B = _crea_pannello(axB, "0.55", "SENZA intervento  (passivo c_nom)")
    for ax in (axT, axB):
        ax.set_ylim(-0.3, _BODY_BASE + _BODY_H + 0.5)
    axB.set_xlabel("posizione strada [m]")

    ybot = -0.3

    def set_panel(P, i, body_y):
        xc = x_pos[i]
        mask = (x_pos >= xc - W) & (x_pos <= xc + W)
        rx = x_pos[mask]; ry = road_y[mask]
        P["road"].set_data(rx, ry)
        # asfalto pieno sotto la strada
        verts = np.column_stack([np.r_[rx, rx[-1], rx[0]], np.r_[ry, ybot, ybot]])
        P["asfalto"].set_xy(verts)
        # ruota tangente all'asfalto: centro = quota strada locale + raggio
        z_road_here = road_y[i]
        cyr = z_road_here + _R_W
        P["tire"].center = (xc, cyr); P["hub"].center = (xc, cyr)
        # cassa
        P["body"].set_xy((xc - _BODY_W / 2, body_y[i]))
        # molla (sx) e ammortizzatore/attuatore (dx) tra sommità ruota e base cassa
        y_top_wheel = cyr + _R_W
        sx, sy = _spring_zig(xc - 0.28, y_top_wheel, body_y[i])
        P["spring"].set_data(sx, sy)
        P["damper"].set_data([xc + 0.28, xc + 0.28], [y_top_wheel, body_y[i]])

    def update(i):
        set_panel(A, i, body_yc)
        set_panel(B, i, body_yp)
        rms_c = np.sqrt(np.mean(traj["az_c"][:i+1] ** 2))
        rms_p = np.sqrt(np.mean(traj["az_p"][:i+1] ** 2))
        A["txt"].set_text(f"t = {i*dt:4.1f} s     ξ = {traj['xi'][i]:.2f}     "
                          f"F_att = {traj['F'][i]:+5.0f} N     RMS a_z = {rms_c:.2f} m/s²")
        B["txt"].set_text(f"t = {i*dt:4.1f} s     c = c_nom fisso"
                          f"                    RMS a_z = {rms_p:.2f} m/s²")
        xc = x_pos[i]
        axT.set_xlim(xc - W, xc + W); axB.set_xlim(xc - W, xc + W)
        return (A["asfalto"], A["road"], A["tire"], A["hub"], A["body"], A["spring"], A["damper"], A["txt"],
                B["asfalto"], B["road"], B["tire"], B["hub"], B["body"], B["spring"], B["damper"], B["txt"])

    anim = animation.FuncAnimation(fig, update, frames=frames, interval=1000/cfg.anim_fps,
                                   blit=False, repeat=False)

    # 1) salva il VIDEO MP4 (serve ffmpeg installato)
    if path_video and cfg.anim_save_video:
        try:
            from matplotlib.animation import FFMpegWriter
            anim.save(path_video, writer=FFMpegWriter(fps=cfg.anim_fps, bitrate=2600),
                      dpi=120)
            print(f"    [ok] Video salvato: {os.path.basename(path_video)}")
        except Exception as e:
            print(f"    [i] MP4 non salvato (installa ffmpeg: 'brew install ffmpeg'). Dettaglio: {e}")

    # 2) apre la finestra interattiva Python
    if mostra:
        plt.show()
    else:
        plt.close(fig)
    return anim


# =====================================================================
# 8. PIPELINE
# =====================================================================
def main():
    t0 = time.time()
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        base_dir = os.path.expanduser("~/Desktop")
    path_xi = os.path.join(base_dir, "cnn_xi.pt")
    path_F = os.path.join(base_dir, "cnn_Fatt.pt")
    fig_path = os.path.join(base_dir, "risultati_sospensione.png")

    print("=" * 94)
    print(" SOSPENSIONE 2 GDL (PEUGEOT 207) — ξ e kp ADATTIVI ALLA STRADA+VELOCITÀ (regola √2·ωn)")
    print(f" ωn = {CAR.wn:.2f} rad/s ({CAR.wn/(2*np.pi):.2f} Hz)   |   √2·ωn = {np.sqrt(2)*CAR.wn:.2f} rad/s "
          f"({np.sqrt(2)*CAR.wn/(2*np.pi):.2f} Hz)")
    print(f" Crossover a r = ω/ωn = √2 (ω stimata istante per istante da strada+velocità)")
    print(f" ξ ∈ [{CFG.xi_lo:.2f}, {CFG.xi_hi:.2f}]   |   F_att saturata a ±{CFG.F_max:.0f} N (no forza infinita)"
          f"   |   calibrazione ampiezza: {CFG.calibra_ampiezza}")
    print("=" * 94)

    device, n_core = rileva_hardware(CFG)
    gen = PhysicsAdaptiveTargetGenerator(CAR, CFG)

    print("\n[1] Caricamento tracce e generazione target (parallela sui performance core)...")
    tracce_tr, tracce_va = carica_tracce()
    Xaz_tr, Xv_tr, Yxi_tr, YF_tr, Xr_tr, cs_tr = costruisci_finestre(tracce_tr, gen, CFG, n_workers=n_core)
    Xaz_va, Xv_va, Yxi_va, YF_va, Xr_va, cs_va = costruisci_finestre(tracce_va, gen, CFG, n_workers=n_core)
    print(f"    Campioni TRAIN : {len(Xaz_tr)}  (2 tracce)")
    print(f"    Campioni VALID : {len(Xaz_va)}  (3ª traccia, mai vista)")

    def norm_xi(x): return (x - XI_MIN) / (XI_MAX - XI_MIN)
    def denorm_xi(x): return XI_MIN + x * (XI_MAX - XI_MIN)
    def norm_F(x): return x / CFG.F_max
    def denorm_F(x): return x * CFG.F_max

    # dati (in RAM) -> tutti sul DEVICE una volta: si sfrutta la GPU/MPS senza
    # overhead di DataLoader/worker (i core servono per la generazione target)
    def to_dev(a): return torch.tensor(a, dtype=torch.float32, device=device)
    Xaz_tr_t = to_dev(Xaz_tr).unsqueeze(1); Xv_tr_t = to_dev(Xv_tr).unsqueeze(1)
    Yxi_tr_t = to_dev(norm_xi(Yxi_tr)).unsqueeze(1); YF_tr_t = to_dev(norm_F(YF_tr)).unsqueeze(1)
    Xaz_va_t = to_dev(Xaz_va).unsqueeze(1); Xv_va_t = to_dev(Xv_va).unsqueeze(1)
    Yxi_va_t = to_dev(norm_xi(Yxi_va)).unsqueeze(1); YF_va_t = to_dev(norm_F(YF_va)).unsqueeze(1)

    print("\n[2] Addestramento DUE reti SEPARATE (loss e optimizer indipendenti)...")
    net_xi, net_F = crea_reti(CFG)
    net_xi.to(device); net_F.to(device)
    opt_xi = optim.AdamW(net_xi.parameters(), lr=1e-3, weight_decay=1e-4)
    opt_F = optim.AdamW(net_F.parameters(), lr=1e-3, weight_decay=1e-4)
    crit_xi = nn.MSELoss()
    crit_F = nn.MSELoss()


    Ntr = Xaz_tr_t.size(0); Nva = Xaz_va_t.size(0); bs = CFG.batch_size

    # Function Loss per il ciclo 
    def val_loss(net, Yt, criterion):  # <-- AGGIUNTO criterion qui
        net.eval()
        s = 0.0
        with torch.no_grad():
            for i in range(0, Nva, bs):
                nb = min(bs, Nva - i)
                # USIAMO 'criterion' al posto di 'crit'
                s += criterion(net(Xaz_va_t[i:i+bs], Xv_va_t[i:i+bs]), Yt[i:i+bs]).item() * nb
        return s / Nva

    best_xi = best_F = float("inf")
    for epoch in range(1, CFG.epochs + 1):
        net_xi.train()
        net_F.train()
        perm = torch.randperm(Ntr, device=device)
        tlx = tlf = 0.0
        
        for i in range(0, Ntr, bs):
            idx = perm[i:i+bs]
            az = Xaz_tr_t[idx]
            v = Xv_tr_t[idx]
            
            # --- RETE XI (usa crit_xi) ---
            opt_xi.zero_grad()
            lx = crit_xi(net_xi(az, v), Yxi_tr_t[idx])
            lx.backward()
            opt_xi.step()
            
            # --- RETE F_ATT (usa crit_F) ---
            opt_F.zero_grad()
            lf = crit_F(net_F(az, v), YF_tr_t[idx])
            lf.backward()
            opt_F.step()
            
            tlx += lx.item() * idx.size(0)
            tlf += lf.item() * idx.size(0)
            
        tlx /= Ntr
        tlf /= Ntr

        # VALIDAZIONE PASSANDO LE LOSS CORRISPONDENTI
        vlx = val_loss(net_xi, Yxi_va_t, crit_xi)
        vlf = val_loss(net_F, YF_va_t, crit_F)
        if vlx < best_xi:
            best_xi = vlx; torch.save(net_xi.state_dict(), path_xi)
        if vlf < best_F:
            best_F = vlf; torch.save(net_F.state_dict(), path_F)
        if epoch % 5 == 0 or epoch == 1:
            print(f"    Epoca {epoch:02d}/{CFG.epochs} | ξ  train {tlx:.5f} val {vlx:.5f}"
                  f"  |  F_att  train {tlf:.5f} val {vlf:.5f}")

    def predict(net, path):
        net.load_state_dict(torch.load(path, map_location=device)); net.eval()
        outs = []
        with torch.no_grad():
            for i in range(0, Nva, bs):
                outs.append(net(Xaz_va_t[i:i+bs], Xv_va_t[i:i+bs]).cpu())
        return torch.cat(outs).numpy().flatten()

    xi_pred = denorm_xi(predict(net_xi, path_xi))
    F_pred = denorm_F(predict(net_F, path_F))
    xi_true, F_true = Yxi_va, YF_va

    print("\n" + "=" * 94)
    print(" VALIDAZIONE SU TRACCIA ISOLATA (3ª, MAI VISTA)")
    print("=" * 94)
    print(f" ξ(t)     -> R²: {r2_score(xi_true, xi_pred):.4f} | MAE: {mean_absolute_error(xi_true, xi_pred):.4f}")
    print(f" F_att(t) -> R²: {r2_score(F_true, F_pred):.4f} | MAE: {mean_absolute_error(F_true, F_pred):.1f} N")
    print(f" |F_att| max previsto dalla CNN: {np.abs(F_pred).max():.1f} N   (limite {CFG.F_max:.0f} N)")

    # comfort IDEALE (target fisici) — solo di riferimento
    rms_pas_fis = np.mean([p for p, o in (cs_tr + cs_va)])
    rms_opt_fis = np.mean([o for p, o in (cs_tr + cs_va)])

    # comfort REALE in CLOSED-LOOP: la rete legge l'a_z della cassa controllata e comanda
    # ξ e F_att passo-passo. Misurato su un segmento della traccia di validazione.
    az_val, v_val = tracce_va[0]
    nseg = min(len(az_val), int(CFG.comfort_ml_seconds * CFG.fs))
    zr_v, zr_dv = ricostruisci_strada(az_val[:nseg], CFG)
    if CFG.calibra_ampiezza:
        f = np.clip(np.sqrt(np.mean(az_val[:nseg] ** 2)) / (_passive_rms(zr_dv, CAR, CFG) + 1e-9), 0.2, 20.0)
        zr_v *= f; zr_dv *= f
    traj_ml = simula_rami_closed_loop(zr_v, zr_dv, v_val[:nseg], net_xi, net_F, device, CAR, CFG)
    rms_pas = np.sqrt(np.mean(traj_ml["az_p"] ** 2))     # passiva (baseline)
    rms_opt = np.sqrt(np.mean(traj_ml["az_c"] ** 2))     # controllata dal ML (closed-loop)

    print(f"\n Comfort CLOSED-LOOP (valori del ML, {nseg/CFG.fs:.0f} s di validazione):")
    print(f"   passiva {rms_pas:.3f} m/s²  ->  ML {rms_opt:.3f} m/s²  ({100*(1-rms_opt/rms_pas):.1f}% miglioramento)")
    print(f"   [riferimento ideale fisico: {100*(1-rms_opt_fis/rms_pas_fis):.1f}%]")

    print("\n" + "-" * 82)
    print(" REGOLA √2: ξ e kp in funzione del rapporto r = ω/ωn (target sul validation)")
    print(f" (ω stimata da strada+velocità; crossover a r = √2 ≈ {SQRT2:.3f})")
    print("-" * 82)
    r_bins = [0.0, 1.0, SQRT2, 2.0, 10.0]
    r_labels = ["r<1 (ω<<√2ωn)", "1<r<√2 (comfort)", "√2<r<2 (isolam.)", "r>2 (ω>>√2ωn)"]
    print(f"{'Range r':<18} | {'v med [km/h]':<12} | {'ξ medio':<9} | {'c [Ns/m]':<10} | {'kp [Ns/m]':<10} | {'|F_att| [N]'}")
    print("-" * 82)
    for i in range(len(r_bins) - 1):
        m = (Xr_va >= r_bins[i]) & (Xr_va < r_bins[i+1])
        if np.any(m):
            xim = xi_true[m].mean()
            print(f"{r_labels[i]:<18} | {Xv_va[m].mean()*3.6:<12.1f} | {xim:<9.3f} | {CAR.xi_to_c(xim):<10.0f} | "
                  f"{kp_of_r(Xr_va[m].mean(), CFG):<10.0f} | {np.abs(F_true[m]).mean():.0f}")

    if CFG.save_fig:
        salva_figura(xi_true, xi_pred, F_true, F_pred, Xr_va, rms_pas, rms_opt, fig_path)

    # --- Animazione confronto CON vs SENZA intervento (usa i valori del ML) ---
    if CFG.show_anim:
        modo = "ML" if CFG.anim_usa_ml else "fisico"
        print(f"\n[3] Animazione confronto (controllo dai valori {modo})...")
        video_path = os.path.join(base_dir, CFG.anim_video_file)
        if CFG.anim_strada_demo or not tracce_va:
            traj = (simula_demo_ml(net_xi, net_F, device, CAR, CFG) if CFG.anim_usa_ml
                    else simula_demo(CAR, CFG))
        else:
            az_v, v_v = tracce_va[0]
            n_anim = min(len(az_v), int(CFG.anim_seconds * CFG.fs))
            if CFG.anim_usa_ml:
                traj = simula_traiettorie_ml(az_v[:n_anim], v_v[:n_anim], net_xi, net_F, device, CAR, CFG)
            else:
                traj = simula_traiettorie(az_v[:n_anim], v_v[:n_anim], CAR, CFG)
        anima_confronto(traj, CFG, path_video=video_path, mostra=CFG.anim_mostra)

    print("=" * 94)
    print(f"Completato in {time.time()-t0:.1f} s")


if __name__ == "__main__":
    main()
