# -*- coding: utf-8 -*-
"""
hardware.py — Identifica il PC: sceglie il device di calcolo (GPU MPS su Apple Silicon,
altrimenti CUDA, altrimenti CPU) e il numero di PERFORMANCE core (salta gli efficiency
core su Apple Silicon). Serve a usare GPU per l'addestramento e i core per la fisica.
"""
import os
import torch


def rileva_hardware(cfg):
    """Restituisce (device, n_core) e imposta i thread torch per la CPU."""
    if cfg.usa_gpu and torch.cuda.is_available():
        device = torch.device("cuda"); nome = "CUDA: " + torch.cuda.get_device_name(0)
    elif cfg.usa_gpu and getattr(torch.backends, "mps", None) is not None \
            and torch.backends.mps.is_available():
        device = torch.device("mps"); nome = "Apple Silicon GPU (MPS)"
    else:
        device = torch.device("cpu"); nome = "CPU"

    perf = eff = None
    import platform
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        import subprocess
        def leggi(chiave):
            try:
                return int(subprocess.check_output(["sysctl", "-n", chiave]).decode().strip())
            except Exception:
                return None
        perf = leggi("hw.perflevel0.logicalcpu")   # core "performance"
        eff = leggi("hw.perflevel1.logicalcpu")    # core "efficiency" (li saltiamo)

    totali = os.cpu_count() or 1
    n_core = perf if perf else totali
    if cfg.n_core_forza > 0:
        n_core = cfg.n_core_forza
    torch.set_num_threads(max(1, n_core))

    print(f"    HW: {nome}")
    if perf:
        print(f"    Core: {totali} totali -> uso {n_core} performance (salto {eff} efficiency)")
    else:
        print(f"    Core: uso {n_core}")
    return device, n_core
