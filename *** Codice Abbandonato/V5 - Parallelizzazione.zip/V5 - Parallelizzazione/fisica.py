# -*- coding: utf-8 -*-
"""
fisica.py — Modello dinamico quarter-car a 2 GDL, integratore RK4, ricostruzione del
profilo strada dai dati e stima causale della frequenza di eccitazione.

LEGENDA VARIABILI (valida per tutto il pacchetto):
    z_r = quota della STRADA sotto la ruota        [m]   (ingresso/disturbo)
    z_u = quota verticale della RUOTA              [m]   (massa non sospesa)
    z_s = quota verticale della CASSA              [m]   (massa sospesa, "il cielo")
    apice '  = velocita' [m/s] ; apice '' = accelerazione [m/s^2]
    a_z = z_s'' : accelerazione verticale della cassa (cio' che misura l'IMU)
    vel_rel = z_s' - z_u' : velocita' RELATIVA di sospensione (corsa)
Stato integrato x = [x1, x2, x3, x4]:
    x1 = z_s - z_u  (corsa sospensione)        x2 = z_s'  (velocita' cassa)
    x3 = z_u - z_r  (deflessione pneumatico)   x4 = z_u'  (velocita' ruota)
"""
import numpy as np
import scipy.signal as signal


def derivata_stato(x, c, forza_att, zr_dot, auto):
    """Derivata dello stato dx/dt del quarter-car.
    Ingressi: c = smorzamento corrente [Ns/m], forza_att = forza attuatore [N],
              zr_dot = velocita' della strada z_r' [m/s]. Restituisce dx/dt (4,)."""
    m_s, m_u = auto.massa_cassa, auto.massa_ruota
    k_s, k_t = auto.rigid_molla, auto.rigid_gomma
    x1, x2, x3, x4 = x
    vel_rel = x2 - x4
    dx1 = x2 - x4
    dx2 = (-k_s * x1 - c * vel_rel + forza_att) / m_s            # z_s'' (accel. cassa)
    dx3 = x4 - zr_dot
    dx4 = ( k_s * x1 + c * vel_rel - forza_att - k_t * x3) / m_u  # z_u'' (accel. ruota)
    return np.array([dx1, dx2, dx3, dx4])


def passo_rk4(x, c, forza_att, zr0, zr1, auto, h):
    """Un passo di Runge-Kutta 4 (h = passo). zr0, zr1 = velocita' strada a inizio/fine passo."""
    zrm = 0.5 * (zr0 + zr1)
    k1 = derivata_stato(x, c, forza_att, zr0, auto)
    k2 = derivata_stato(x + 0.5 * h * k1, c, forza_att, zrm, auto)
    k3 = derivata_stato(x + 0.5 * h * k2, c, forza_att, zrm, auto)
    k4 = derivata_stato(x + h * k3, c, forza_att, zr1, auto)
    return x + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def rimuovi_offset(az, fs, fc=0.1):
    """Passa-alto zero-fase per togliere offset/deriva dall'accelerazione misurata."""
    b, a = signal.butter(2, fc / (0.5 * fs), btype="highpass")
    return signal.filtfilt(b, a, az)


def despica_hampel(x, finestra=7, n_sigma=3.0):
    """Filtro di Hampel: sostituisce con la mediana locale i campioni che distano piu' di
    n_sigma*MAD dalla mediana. Toglie i PICCHI anomali del sensore ("valori pericolosi")
    senza appiattire il segnale utile. MAD = deviazione mediana assoluta."""
    from scipy.ndimage import median_filter
    x = np.asarray(x, dtype=float)
    med = median_filter(x, size=finestra, mode="nearest")
    mad = median_filter(np.abs(x - med), size=finestra, mode="nearest")
    soglia = n_sigma * 1.4826 * mad + 1e-9        # 1.4826: converte MAD in sigma (rumore gaussiano)
    fuori = np.abs(x - med) > soglia
    y = x.copy(); y[fuori] = med[fuori]
    return y


def ricostruisci_strada(az, cfg):
    """Doppia integrazione (con passa-alto anti-deriva) di a_z -> profilo strada z_r e z_r'.
    L'AMPIEZZA qui e' solo nominale: verra' CALIBRATA sui dati in controllo.py."""
    fs = cfg.freq_campion
    b, a = signal.butter(2, 0.3 / (0.5 * fs), btype="highpass")
    vel = signal.filtfilt(b, a, np.cumsum(az) / fs)      # 1a integrazione -> velocita'
    zr  = signal.filtfilt(b, a, np.cumsum(vel) / fs)     # 2a integrazione -> spostamento
    rms = np.sqrt(np.mean(zr ** 2)) + 1e-9
    zr = zr * (cfg.strada_rms_nom / rms)                 # scala nominale (poi ricalibrata)
    return zr.astype(float), np.gradient(zr, cfg.passo_t).astype(float)


def _kalman_pos_vel(az, cfg):
    """Filtro di Kalman KINEMATICO a 2 stati x = [z_s, z_s'] (posizione, velocita' cassa).
    L'accelerazione misurata a_z e' l'INGRESSO (rumoroso) che integra il modello:
        z_s(k+1) = z_s + dt*z_s' + 0.5*dt^2*a_z ,   z_s'(k+1) = z_s' + dt*a_z
    Per impedire la DERIVA dell'integrazione si usa una pseudo-misura "posizione ~ 0"
    (lo spostamento di comfort e' a media nulla): agisce come passa-alto OTTIMO.
    sigma_a (rumore accel.) e' stimato DAI DATI (MAD robusto sulle differenze).
    Restituisce la velocita' cassa denoised, causale (usa solo il passato)."""
    dt = cfg.passo_t
    F = np.array([[1.0, dt], [0.0, 1.0]])
    B = np.array([[0.5 * dt * dt], [dt]])
    diff = np.diff(np.asarray(az, dtype=float))
    sigma_a = 1.4826 * np.median(np.abs(diff - np.median(diff))) + 1e-6   # rumore accel dai dati
    Q = (B @ B.T) * (sigma_a ** 2)                       # rumore di processo dall'ingresso rumoroso
    H = np.array([[1.0, 0.0]])                            # osserviamo (fittiziamente) la posizione
    R = np.array([[cfg.kalman_scala_pos ** 2]])           # varianza attesa dello spostamento
    x = np.zeros((2, 1)); P = np.eye(2) * 1e-4; I = np.eye(2)
    N = len(az); vel = np.zeros(N)
    for k in range(N):
        x = F @ x + B * az[k]                            # predizione con a_z come ingresso
        P = F @ P @ F.T + Q
        S = H @ P @ H.T + R                              # correzione: pseudo-misura posizione = 0
        K = P @ H.T / S
        x = x + K * (0.0 - (H @ x))
        P = (I - K @ H) @ P
        vel[k] = x[1, 0]
    return vel


def velocita_cassa_misurata(az, cfg):
    """Velocita' verticale della cassa dall'a_z del sensore (grandezza su cui agisce lo
    skyhook). Con cfg.usa_kalman -> filtro di Kalman (denoising ottimo, anti-deriva);
    altrimenti -> integrale singolo passa-alto (piu' semplice, piu' rumoroso)."""
    vel = _kalman_pos_vel(az, cfg) if cfg.usa_kalman else \
        signal.lfilter(*signal.butter(2, 0.3 / (0.5 * cfg.freq_campion), btype="highpass"),
                       np.cumsum(az) / cfg.freq_campion)
    # COMPENSAZIONE LATENZA (opzionale): v(k+n*dt) ~ v(k) + n*dt*a_z(k). Anticipa la velocita'
    # usando l'accelerazione MISURATA (no differenziazione -> poco rumore) -> lo skyhook non e'
    # piu' in ritardo di fase. n=0 la disattiva.
    if cfg.n_lead_latenza > 0:
        vel = vel + cfg.n_lead_latenza * cfg.passo_t * np.asarray(az, dtype=float)
    return vel


def _freq_velocita(v, cfg, auto):
    """r = omega/omega_n con omega = 2*pi*v/lambda_c: la frequenza DOMINANTE di eccitazione
    stradale scala con la VELOCITA' (per una strada ISO lo spettro ha pendenza fissa, quindi
    la rugosita' cambia l'ampiezza ma NON la frequenza dominante). v_crossover = velocita' a
    cui r=√2. Robusto: non e' falsato dalle risonanze del veicolo (come invece l'a_z)."""
    return np.clip(np.sqrt(2.0) * np.asarray(v, dtype=float) / cfg.v_crossover, 0.15, cfg.r_max).astype(np.float32)


def stima_frequenza(az, v, cfg, auto):
    """Rapporto r = omega/omega_n. Metodi (cfg.metodo_freq):
       'velocita' -> dalla VELOCITA' (eccitazione stradale ~ v): ADATTIVO e robusto (default);
       'fft'      -> centroide spettrale dell'a_z (falsato dalle risonanze del veicolo);
       'rms'      -> rapporto RMS dell'a_z."""
    if cfg.metodo_freq == "velocita":
        return _freq_velocita(v, cfg, auto)
    if cfg.metodo_freq == "fft":
        return _freq_fft(az, cfg, auto)
    return _freq_rms(az, cfg, auto)


def _freq_rms(az, cfg, auto):
    fs = cfg.freq_campion
    b, a = signal.butter(2, 0.3 / (0.5 * fs), btype="highpass")
    vz = signal.lfilter(b, a, np.cumsum(az) / fs)        # integrale causale di a_z
    w = cfg.finestra_freq

    def rms_trailing(s):
        somma = np.convolve(s * s, np.ones(w), mode="full")[:len(s)] / w
        return np.sqrt(np.maximum(somma, 0.0) + 1e-12)

    omega = rms_trailing(az) / (rms_trailing(vz) + 1e-9)
    return np.clip(omega / auto.puls_nat_cassa, 0.15, cfg.r_max)


def _freq_fft(az, cfg, auto):
    """Centroide spettrale su finestra TRAILING via FFT (batch = veloce, e causale):
    r[i] usa gli ultimi finestra_freq campioni fino a i. La finestra di Hann riduce il
    leakage spettrale (condizionamento in frequenza)."""
    from numpy.lib.stride_tricks import sliding_window_view
    N = len(az); w = cfg.finestra_freq
    if N <= w:
        return np.full(N, 1.0, np.float32)
    W = sliding_window_view(az, w)                       # riga j = finestra che finisce al campione j+w-1
    hann = np.hanning(w)
    Wf = (W - W.mean(axis=1, keepdims=True)) * hann      # togli media + finestratura
    potenza = np.abs(np.fft.rfft(Wf, axis=1)) ** 2
    freq_hz = np.fft.rfftfreq(w, d=cfg.passo_t)
    # considera solo la BANDA dinamica della sospensione (toglie DC/quasi-statico e rumore alto)
    lo, hi = cfg.freq_banda_hz
    banda = (freq_hz >= lo) & (freq_hz <= hi)
    potenza = potenza[:, banda]; freq_hz = freq_hz[banda]
    centro_hz = (potenza * freq_hz).sum(1) / (potenza.sum(1) + 1e-12)   # frequenza media pesata [Hz]
    r_win = np.clip(2 * np.pi * centro_hz / auto.puls_nat_cassa, 0.15, cfg.r_max).astype(np.float32)
    r = np.empty(N, np.float32)
    r[w - 1:] = r_win                                    # allineamento causale (fine finestra)
    r[:w - 1] = r_win[0]
    return r


def rms_accel_passiva(zr_dot, auto, cfg):
    """RMS dell'accelerazione cassa del modello PASSIVO (c_nom, senza attuatore).
    Serve per CALIBRARE l'ampiezza strada sui dati (vedi controllo.py): NON e' un numero
    magico, e' cio' che permette di scalare z_r finche' il passivo riproduce l'a_z misurato."""
    N = len(zr_dot)
    xp = np.zeros(4)
    h = cfg.passo_t / cfg.n_sottopassi
    acc = 0.0
    for k in range(N):
        acc += (-auto.rigid_molla * xp[0] - auto.smorz_nom * (xp[1] - xp[3])) ** 2
        zr0 = zr_dot[k]
        zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
        for _ in range(cfg.n_sottopassi):
            xp = passo_rk4(xp, auto.smorz_nom, 0.0, zr0, zr1, auto, h)
    return np.sqrt(acc / N) / auto.massa_cassa


def accel_passiva_serie(zr_dot, auto, cfg):
    """Accelerazione cassa (serie temporale) del modello PASSIVO su un profilo strada.
    Serve a generare l'a_z 'misurata' delle strade SINTETICHE (data augmentation)."""
    N = len(zr_dot); xp = np.zeros(4); az = np.zeros(N); h = cfg.passo_t / cfg.n_sottopassi
    for k in range(N):
        az[k] = (-auto.rigid_molla * xp[0] - auto.smorz_nom * (xp[1] - xp[3])) / auto.massa_cassa
        zr0 = zr_dot[k]; zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
        for _ in range(cfg.n_sottopassi):
            xp = passo_rk4(xp, auto.smorz_nom, 0.0, zr0, zr1, auto, h)
    return az
