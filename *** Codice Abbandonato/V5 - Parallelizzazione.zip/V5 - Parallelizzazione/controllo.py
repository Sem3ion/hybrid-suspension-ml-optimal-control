# -*- coding: utf-8 -*-
"""
controllo.py — Legge di controllo di RIFERIMENTO (regola della trasmissibilita' √2) e
generazione delle ETICHETTE (target) che il ML dovra' imparare a riprodurre.

Cosa produce, per ogni traccia, il GeneratoreEtichette:
    - xi(t)    : fattore di smorzamento (regola √2 sulla frequenza stimata dai dati)
    - forza(t) : forza skyhook sulla velocita' cassa MISURATA (coerente col sensore)
    - acc_passiva / acc_ideale : accelerazione cassa passiva e ideale, per il comfort.
"""
import numpy as np
from fisica import (ricostruisci_strada, velocita_cassa_misurata, stima_frequenza,
                    rms_accel_passiva, passo_rk4)

RADQ2 = np.sqrt(2.0)


def xi_da_r(r, cfg):
    """xi in funzione di r = omega/omega_n (regola √2):
       r < √2 -> xi alto (sotto risonanza piu' smorzamento aiuta il comfort);
       r > √2 -> xi basso (sopra risonanza conviene isolare). Transizione morbida."""
    z = cfg.pendenza_sched * (r / RADQ2 - 1.0)
    return cfg.xi_basso + (cfg.xi_alto - cfg.xi_basso) / (1.0 + np.exp(z))


def kp_da_r(r, cfg):
    """Guadagno skyhook dell'attuatore [Ns/m]: basso sotto √2, alto sopra (compensa il
    damper reso morbido ad alta frequenza tenendo ferma la cassa)."""
    z = cfg.pendenza_sched * (r / RADQ2 - 1.0)
    return cfg.kp_basso + (cfg.kp_alto - cfg.kp_basso) / (1.0 + np.exp(-z))


class GeneratoreEtichette:
    """Genera i target 'ideali' simulando il modello fisico su ogni traccia reale."""

    def __init__(self, auto, cfg):
        self.auto = auto
        self.cfg = cfg

    def genera(self, az, v):
        """Ingressi: a_z (accel. cassa misurata) e v (velocita' GPS) di una traccia.
        Uscita: dict con etichette xi/forza, r, accelerazioni passiva/ideale, strada."""
        auto, cfg = self.auto, self.cfg
        N = len(az)
        zr, zr_dot = ricostruisci_strada(az, cfg)

        # CALIBRAZIONE ampiezza strada DAI DATI (niente numero magico): scalo z_r finche'
        # il modello passivo riproduce l'RMS dell'a_z MISURATO -> forze in Newton reali.
        if cfg.calibra_strada:
            rms_misurato = np.sqrt(np.mean(az ** 2))
            rms_passivo = rms_accel_passiva(zr_dot, auto, cfg)
            fattore = np.clip(rms_misurato / (rms_passivo + 1e-9), 0.2, 20.0)
            zr = zr * fattore
            zr_dot = zr_dot * fattore

        r = stima_frequenza(az, v, cfg, auto)         # r = omega/omega_n (dalla velocita')
        xi = xi_da_r(r, cfg)
        kp = kp_da_r(r, cfg)
        c = auto.c_da_xi(xi)
        vel_cassa_mis = velocita_cassa_misurata(az, cfg)   # per lo skyhook (etichetta forza)

        # ETICHETTA forza per il ML: skyhook sulla velocita' MISURATA (input e target coerenti)
        forza_lab = np.clip(-kp * vel_cassa_mis, -cfg.forza_max, cfg.forza_max)

        acc_passiva = np.zeros(N)
        acc_ideale = np.zeros(N)
        x = np.zeros(4)     # ramo ideale (skyhook su stato vero)
        xp = np.zeros(4)    # ramo passivo (c_nom)
        h = cfg.passo_t / cfg.n_sottopassi
        for k in range(N):
            vel_rel = x[1] - x[3]
            # RIFERIMENTO ideale (best-case): skyhook sullo STATO VERO, usato per guidare
            # davvero il plant -> acc_ideale e' un limite superiore coerente per il comfort.
            forza_id = np.clip(-kp[k] * x[1], -cfg.forza_max, cfg.forza_max)
            acc_ideale[k] = (-auto.rigid_molla * x[0] - c[k] * vel_rel + forza_id) / auto.massa_cassa
            acc_passiva[k] = (-auto.rigid_molla * xp[0] - auto.smorz_nom * (xp[1] - xp[3])) / auto.massa_cassa
            zr0 = zr_dot[k]
            zr1 = zr_dot[k + 1] if k + 1 < N else zr_dot[k]
            for _ in range(cfg.n_sottopassi):
                x = passo_rk4(x, c[k], forza_id, zr0, zr1, auto, h)
                xp = passo_rk4(xp, auto.smorz_nom, 0.0, zr0, zr1, auto, h)

        return dict(xi=xi.astype(np.float32), forza=forza_lab.astype(np.float32),
                    r=r.astype(np.float32), acc_passiva=acc_passiva, acc_ideale=acc_ideale,
                    strada=zr, N=N)
