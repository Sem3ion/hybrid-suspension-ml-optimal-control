# -*- coding: utf-8 -*-
"""
strade_sintetiche.py — DATA AUGMENTATION fisica.

Le 2 tracce reali coprono solo guida liscia a ~30 km/h. Qui GENERIAMO strade varie
(rugosita' ISO 8608 classi A..E, velocita' diverse, salite/discese, buche) e ricaviamo
l'accelerazione a_z che il sensore misurerebbe simulando il modello PASSIVO. Cosi'
il training vede anche casi sconnessi/veloci e forze grandi. Le tracce reali restano
per la VALIDAZIONE. I target sono poi calcolati dalla stessa fisica (controllo.py).

ISO 8608: densita' spettrale del profilo strada  Gd(n) = Gd(n0)*(n/n0)^(-2),
con n = frequenza spaziale [cicli/m], n0 = 0.1, e Gd(n0) che cresce con la classe.
"""
import numpy as np
from fisica import accel_passiva_serie

# Gd(n0) [m^3] per classe ISO 8608 (A liscia -> E molto sconnessa), n0 = 0.1 cicli/m
_GD0 = {"A": 16e-6, "B": 64e-6, "C": 256e-6, "D": 1024e-6, "E": 4096e-6}


def _profilo_iso8608(classe, x, rng, n_min=0.011, n_max=2.83, n_freq=300):
    """Profilo strada z_r(x) [m] per la classe data, sintesi a somma di sinusoidi (ISO 8608)."""
    n = np.linspace(n_min, n_max, n_freq)          # frequenze spaziali [cicli/m]
    dn = n[1] - n[0]
    Gd = _GD0[classe] * (n / 0.1) ** (-2)            # densita' spettrale
    amp = np.sqrt(2.0 * Gd * dn)                     # ampiezza di ogni sinusoide
    phi = rng.uniform(0, 2 * np.pi, n_freq)
    # z_r(x) = somma_i amp_i * cos(2*pi*n_i*x + phi_i)   (matrice x-per-n)
    return (amp[None, :] * np.cos(2 * np.pi * np.outer(x, n) + phi[None, :])).sum(axis=1)


def _aggiungi_buche(zr, x, rng, n_buche, prof_min=0.02, prof_max=0.08, largh=0.4):
    """Buche/dossi isolati: avvallamenti gaussiani a posizioni casuali (profondita' variabile)."""
    for _ in range(n_buche):
        xb = rng.uniform(x[0] + 5, x[-1] - 5)
        prof = rng.uniform(prof_min, prof_max) * rng.choice([-1.0, 1.0])  # buca (giu') o dosso (su')
        zr = zr + prof * np.exp(-((x - xb) ** 2) / (2 * largh ** 2))
    return zr


def _salita_discesa(x, rng):
    """Ondulazioni lente del terreno (salite/discese): lunghezza d'onda 40..150 m, ampiezza cm-dm.
    NB: la componente quasi-statica viene poi tolta dal passa-alto; conta la sua VARIAZIONE."""
    lam = rng.uniform(40.0, 150.0)                  # lunghezza d'onda collina [m]
    amp = rng.uniform(0.05, 0.30)                   # dislivello [m]
    fase = rng.uniform(0, 2 * np.pi)
    return amp * np.sin(2 * np.pi * x / lam + fase)


def genera_tracce_sintetiche(auto, cfg):
    """Restituisce una lista di tracce (a_z, v) sintetiche da aggiungere al TRAINING."""
    rng = np.random.default_rng(1234)
    classi = ["B", "C", "C", "D", "D", "E"]         # da abbastanza liscio a molto sconnesso
    velocita = [8.0, 14.0, 20.0, 25.0, 16.0, 11.0]  # m/s (diverse -> copre r bassi e alti)
    N = int(cfg.aug_secondi * cfg.freq_campion)
    tracce = []
    for i in range(cfg.n_tracce_sintetiche):
        classe = classi[i % len(classi)]
        v0 = velocita[i % len(velocita)]
        v = np.full(N, v0) + rng.normal(0, 0.3, N)   # velocita' quasi costante con piccole variazioni
        v = np.clip(v, 3.0, 33.0)
        x = np.cumsum(v * cfg.passo_t)               # avanzamento longitudinale [m]
        zr = _profilo_iso8608(classe, x, rng)
        zr = zr + _salita_discesa(x, rng)            # salite/discese
        zr = _aggiungi_buche(zr, x, rng, n_buche=rng.integers(3, 8))
        zr_dot = np.gradient(zr, cfg.passo_t)
        az_pulita = accel_passiva_serie(zr_dot, auto, cfg)   # a_z del modello passivo
        # rumore del sensore realistico: gaussiano + qualche picco (li togliera' il despiking)
        az = az_pulita + rng.normal(0, 0.05, N)
        for _ in range(rng.integers(2, 6)):
            az[rng.integers(N)] += rng.uniform(2, 6) * rng.choice([-1.0, 1.0])
        tracce.append((az.astype(float), v.astype(float)))
        print(f"      strada sintetica {i+1}: classe {classe}, v0={v0*3.6:.0f} km/h, "
              f"RMS a_z={np.sqrt(np.mean(az_pulita**2)):.2f} m/s^2")
    return tracce
