# -*- coding: utf-8 -*-
"""
config.py — Parametri FISICI dell'auto e scelte di progetto del controllore.

Qui dentro si trovano i  parametri di MODELLO (specifiche del veicolo) e di PROGETTO del controllo
closed-loop per comandare il sistema ibrido di sospensione skyhook + smorzatore variabile.
"""
from dataclasses import dataclass
import numpy as np


@dataclass
class Auto:
    """Peugeot 207 come quarter-car a 2 gradi di liberta' (cassa + ruota)."""
    massa_cassa: float = 260.0      # m_s  massa sospesa (carrozzeria)          [kg]
    massa_ruota: float = 38.0       # m_u  massa non sospesa (ruota + mozzo)    [kg]
    rigid_molla: float = 23000.0    # k_s  rigidezza molla sospensione          [N/m]
    rigid_gomma: float = 190000.0   # k_t  rigidezza verticale pneumatico       [N/m]
    smorz_min: float = 800.0        # c_min ammortizzatore: minimo realizzabile [Ns/m]
    smorz_max: float = 3200.0       # c_max ammortizzatore: massimo realizzabile[Ns/m]
    smorz_nom: float = 1500.0       # c_nom valore passivo di riferimento       [Ns/m]

    @property
    def puls_nat_cassa(self):
        """omega_n = sqrt(k_s/m_s): pulsazione naturale della cassa [rad/s] (~9.4 = 1.5 Hz)."""
        return np.sqrt(self.rigid_molla / self.massa_cassa)

    @property
    def smorz_critico(self):
        """c_crit = 2*sqrt(k_s*m_s): smorzamento critico [Ns/m]. Serve per xi = c/c_crit."""
        return 2.0 * np.sqrt(self.rigid_molla * self.massa_cassa)

    def c_da_xi(self, xi):
        """Da fattore di smorzamento adimensionale xi al coefficiente c [Ns/m]."""
        return xi * self.smorz_critico

    def xi_da_c(self, c):
        """Da coefficiente c [Ns/m] al fattore di smorzamento adimensionale xi."""
        return c / self.smorz_critico


@dataclass
class Config:
    """Scelte di progetto del controllore e dell'addestramento (tutte commentate)."""
    # --- campionamento e integrazione ---
    freq_campion: float = 100.0     # frequenza di campionamento/controllo       [Hz]
    passo_t: float = 0.01           # passo temporale dt = 1/freq_campion         [s]
    n_sottopassi: int = 2           # sotto-passi RK4 per stabilita' numerica
    seq_len: int = 100              # lunghezza finestra a_z data alle reti (1.0 s)
    finestra_freq: int = 100        # finestra per la stima causale della frequenza (1.0 s)

    # --- limiti FISICI dell'attuatore/strada (non normalizzazione) ---
    forza_max: float = 1500.0       # saturazione forza attuatore [N] (no forza infinita)
    strada_rms_nom: float = 0.010   # RMS nominale strada prima della calibrazione [m]
    calibra_strada: bool = True     # calibra l'ampiezza strada sui DATI (RMS a_z misurato)
    r_max: float = 5.0              # clip di r = omega/omega_n per robustezza

    # --- condizionamento del segnale (pulizia dati) ---
    despica: bool = True            # filtro di Hampel: rimuove i picchi anomali del sensore
    hampel_finestra: int = 7        # ampiezza finestra mediana per il despiking
    hampel_sigma: float = 3.0       # soglia in n. di deviazioni (MAD) oltre cui e' outlier
    metodo_freq: str = "fft"        # "fft" (centroide spettrale, piu' pulito) o "rms" (rapporto)
    freq_banda_hz: tuple = (0.3, 6.0)   # banda del MODO CASSA per la regola √2 (esclude hop ruota ~12 Hz e rumore)
    # --- attivazioni delle reti (relu/gelu/silu/mish/elu/leaky) ---
    att_xi: str = "relu"
    att_forza: str = "gelu"
    # --- filtro di Kalman per la velocita' cassa (denoising ottimo) ---
    usa_kalman: bool = True         # stima z_s' con Kalman invece dell'integrale semplice
    kalman_scala_pos: float = 0.02  # scala tipica spostamento comfort [m] (forza dell'anti-deriva)
    # --- data augmentation: strade sintetiche ISO 8608 (+ salite/discese + buche) ---
    usa_augmentation: bool = True
    n_tracce_sintetiche: int = 6    # quante strade sintetiche aggiungere al TRAINING
    aug_secondi: float = 60.0       # durata di ogni traccia sintetica [s]

    # --- regola della trasmissibilita' √2 (scheduling di xi e kp) ---
    pendenza_sched: float = 4.0     # ripidita' della transizione attorno a r = √2
    xi_alto: float = 0.60           # xi per r < √2 (comfort/controllo)
    xi_basso: float = 0.18          # xi per r > √2 (isolamento)
    kp_basso: float = 200.0         # guadagno skyhook attuatore per r < √2 [Ns/m]
    kp_alto: float = 2500.0         # guadagno skyhook attuatore per r > √2 [Ns/m]

    # --- addestramento ---
    n_epoche: int = 12
    batch: int = 256                # batch grande = meno overhead su GPU/MPS
    usa_gpu: bool = True            # usa MPS (Apple Silicon) / CUDA se disponibili
    n_core_forza: int = -1          # -1 = auto (solo performance core); >0 = forza N core
    comfort_secondi: float = 60.0   # durata segmento su cui misurare il comfort ML (closed-loop)

    # --- output ---
    salva_figura: bool = True
    mostra_anim: bool = True        # apre la finestra interattiva dell'animazione
    salva_video: bool = True        # salva anche l'MP4 (richiede ffmpeg)
    video_file: str = "confronto_sospensione.mp4"
    figura_file: str = "risultati_sospensione.png"

    # --- animazione (parametri di sola resa grafica) ---
    anim_usa_ml: bool = True        # controllo dai valori PREDETTI dal ML (non i target)
    anim_secondi: float = 8.0       # durata simulata da animare [s]
    anim_vel: float = 7.0           # velocita' di avanzamento nella demo [m/s]
    anim_dosso: float = 0.06        # altezza dossi strada demo [m] (piu' alto = piu' sconnessa)
    anim_texture: float = 0.006     # rugosita' fine sovrapposta ai dossi [m]
    anim_gain: float = 6.0          # ingrandimento verticale del movimento (resa grafica)
    anim_step: int = 2              # sotto-campionamento frame
    anim_fps: int = 24              # fps del video
